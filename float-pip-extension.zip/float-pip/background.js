// Service worker: debug log storage, SponsorBlock fetch, keyboard command.
const MAX_LOGS = 3000;
let debugOn = true;
let queue = Promise.resolve();

chrome.storage.sync.get({ debug: true }).then(s => { debugOn = s.debug; });
chrome.storage.onChanged.addListener((c, area) => {
  if (area === 'sync' && c.debug) debugOn = c.debug.newValue;
});

function append(entry) {
  if (!debugOn) return;
  queue = queue.then(async () => {
    const { logs = [] } = await chrome.storage.local.get('logs');
    logs.push(entry);
    if (logs.length > MAX_LOGS) logs.splice(0, logs.length - MAX_LOGS);
    await chrome.storage.local.set({ logs });
  }).catch(() => {});
}
const bgLog = (level, msg, data) =>
  append({ ts: new Date().toISOString(), level, src: 'background', msg, data });

// SponsorBlock with small cache
const sbCache = new Map();
async function fetchSegments(videoId) {
  if (sbCache.has(videoId)) return sbCache.get(videoId);
  const cats = encodeURIComponent(JSON.stringify(['sponsor', 'selfpromo', 'interaction', 'intro', 'outro']));
  const url = `https://sponsor.ajay.app/api/skipSegments?videoID=${encodeURIComponent(videoId)}&categories=${cats}`;
  try {
    const r = await fetch(url);
    if (r.status === 404) { sbCache.set(videoId, []); bgLog('info', 'SponsorBlock: no segments', { videoId }); return []; }
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const data = await r.json();
    const segs = data.map(d => ({ segment: d.segment, category: d.category }));
    if (sbCache.size > 200) sbCache.clear();
    sbCache.set(videoId, segs);
    bgLog('info', 'SponsorBlock segments loaded', { videoId, count: segs.length });
    return segs;
  } catch (e) {
    bgLog('warn', 'SponsorBlock fetch failed', String(e));
    return [];
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return false;
  if (msg.type === 'log') { append(msg.entry); return false; }
  if (msg.type === 'sponsorblock') {
    fetchSegments(msg.videoId).then(segments => sendResponse({ segments }));
    return true;
  }
  return false;
});

// ---- Popup window mode (real YouTube watch page in a small window) ----
async function getPopups() { const { popupWins = [] } = await chrome.storage.session.get('popupWins'); return popupWins; }
chrome.windows.onRemoved.addListener(async (id) => {
  const l = await getPopups();
  if (l.includes(id)) await chrome.storage.session.set({ popupWins: l.filter(x => x !== id) });
});
async function openPopup(msg) {
  const url = `https://www.youtube.com/watch?v=${encodeURIComponent(msg.videoId)}${msg.t ? '&t=' + Math.floor(msg.t) + 's' : ''}`;
  // Pehle se khuli popup window ho to usi me naya video load karo (windows ka dher na lage)
  const list = await getPopups();
  for (const id of [...list].reverse()) {
    try {
      const w = await chrome.windows.get(id, { populate: true });
      const tab = w.tabs && w.tabs[0];
      if (!tab) continue;
      await chrome.tabs.update(tab.id, { url });
      await chrome.windows.update(id, { focused: true, drawAttention: true });
      bgLog('info', 'Reused popup window', { videoId: msg.videoId, windowId: id });
      return;
    } catch (e) { /* window band ho chuki hai */ }
  }
  const W = 640, H = 400;
  const opts = { url, type: 'popup', width: W, height: H, focused: true };
  const sc = msg.screen;
  if (sc && typeof sc.w === 'number' && sc.w > 0) {           // screen ke bottom-right corner me
    opts.left = Math.max(0, Math.round(sc.l + sc.w - W - 16));
    opts.top = Math.max(0, Math.round(sc.t + sc.h - H - 16));
  }
  const w = await chrome.windows.create(opts);
  const l = await getPopups(); l.push(w.id);
  await chrome.storage.session.set({ popupWins: l });
  bgLog('info', 'Popup window opened', { videoId: msg.videoId, windowId: w.id });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return false;
  if (msg.type === 'openPopup') {
    openPopup(msg).catch(e => bgLog('error', 'Popup window failed', String(e)));
    return false;
  }
  if (msg.type === 'isPopupWin') {
    getPopups().then(l => sendResponse({ popup: !!(sender.tab && l.includes(sender.tab.windowId)) }));
    return true;
  }
  return false;
});

chrome.commands.onCommand.addListener(async (command, tab) => {
  bgLog('info', 'Command', { command });
  if (command !== 'toggle-pip') return;
  try {
    const t = tab || (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
    if (t && t.id != null) await chrome.tabs.sendMessage(t.id, { type: 'toggle-pip' });
  } catch (e) { bgLog('error', 'Command dispatch failed', String(e)); }
});

chrome.runtime.onInstalled.addListener((d) => bgLog('info', 'Extension installed/updated', { reason: d.reason }));
