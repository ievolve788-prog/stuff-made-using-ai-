Float Anything PiP v1.1.0 - install
1. chrome://extensions kholo, Developer mode ON
2. Load unpacked -> is folder ko select karo (purana version ho to reload karo aur YouTube tab refresh karo)
3. YouTube pe thumbnail par hover karo -> '⧉ Float' button -> click.
