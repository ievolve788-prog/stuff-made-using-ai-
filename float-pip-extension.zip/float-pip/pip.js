// Opens the real YouTube watch page in a small popup window (reused if already open).
(() => {
  const NS = window.__ytpip;
  if (!NS || NS.openVideo) return;
  const { log } = NS;

  NS.openPopupWindow = (id, t = 0) => {
    log('info', 'Opening YouTube popup window', { id, t });
    try {
      chrome.runtime.sendMessage({
        type: 'openPopup', videoId: id, t,
        screen: { l: screen.availLeft || 0, t: screen.availTop || 0, w: screen.availWidth, h: screen.availHeight }
      }).catch(() => {});
    } catch (e) { log('error', 'openPopup message failed', e); }
  };
  NS.openVideo = (id /*, title */) => NS.openPopupWindow(id, 0);
})();
