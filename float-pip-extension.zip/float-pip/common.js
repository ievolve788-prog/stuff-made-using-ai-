// Shared helpers: settings, logging, video picking, native PiP, auto-PiP.
(() => {
  if (window.__ytpip && window.__ytpip.ready) return;
  const NS = (window.__ytpip = window.__ytpip || {});
  NS.ready = true;

  const DEFAULTS = {
    enabled: true, mode: 'button', sponsorblock: true,
    autoTrigger: true, debug: true, speed: 1, volume: 100
  };
  NS.DEFAULTS = DEFAULTS;
  NS.settings = { ...DEFAULTS };

  NS.loadSettings = async () => {
    try { NS.settings = await chrome.storage.sync.get(DEFAULTS); } catch (e) {}
    return NS.settings;
  };
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'sync') return;
      for (const k in changes) NS.settings[k] = changes[k].newValue;
    });
  } catch (e) {}

  // ---- Logging (background me store hota hai, popup se .txt download) ----
  const ser = (d) => {
    if (d === undefined) return undefined;
    if (d instanceof Error) return d.name + ': ' + d.message;
    try { return JSON.parse(JSON.stringify(d)); } catch { return String(d); }
  };
  NS.log = (level, msg, data) => {
    try {
      chrome.runtime.sendMessage({
        type: 'log',
        entry: { ts: new Date().toISOString(), level, src: location.hostname, msg, data: ser(data) }
      }).catch(() => {});
    } catch (e) { /* extension context invalidated */ }
  };

  // ---- YouTube URL -> video id ----
  NS.parseId = (href) => {
    try {
      const u = new URL(href, location.href);
      if (u.hostname === 'youtu.be') return u.pathname.slice(1) || null;
      if (!/(^|\.)youtube\.com$/.test(u.hostname)) return null;
      if (u.pathname === '/watch') return u.searchParams.get('v');
      const m = u.pathname.match(/^\/(shorts|live|embed)\/([\w-]{6,})/);
      return m ? m[2] : null;
    } catch { return null; }
  };

  // ---- SponsorBlock (fetch background se hota hai) ----
  NS.getSegments = async (id) => {
    try {
      const r = await chrome.runtime.sendMessage({ type: 'sponsorblock', videoId: id });
      return (r && r.segments) || [];
    } catch (e) { NS.log('warn', 'getSegments failed', e); return []; }
  };

  // ---- Native PiP helpers ----
  NS.pickVideo = () => {
    const area = (v) => { const r = v.getBoundingClientRect(); return r.width * r.height; };
    const vids = [...document.querySelectorAll('video')].filter(v => v.readyState > 1 && v.videoWidth > 0 && !v.ended);
    vids.sort((a, b) => (Number(!b.paused) - Number(!a.paused)) || (area(b) - area(a)));
    return vids[0] || null;
  };

  NS.enterNativePip = async (video, why) => {
    video.disablePictureInPicture = false;
    await video.requestPictureInPicture();
    NS.log('info', 'Native PiP entered', { why });
  };

  NS.toggleNativePip = async () => {
    if (document.pictureInPictureElement) {
      await document.exitPictureInPicture();
      NS.log('info', 'Native PiP exited (toggle)');
      return;
    }
    const v = NS.pickVideo();
    if (!v) { NS.log('warn', 'toggle-pip: koi video nahi mila'); return; }
    await NS.enterNativePip(v, 'toggle');
  };

  // ---- Smart auto-trigger (tab switch) ----
  let autoEntered = false;
  document.addEventListener('leavepictureinpicture', () => { autoEntered = false; }, true);

  NS.setupAutoPip = () => {
    const tryEnter = async (why) => {
      const s = NS.settings;
      if (!s.enabled || !s.autoTrigger || document.pictureInPictureElement) return;
      const v = NS.pickVideo();
      if (!v || v.paused) return;
      try { await NS.enterNativePip(v, 'auto:' + why); autoEntered = true; }
      catch (e) { NS.log('debug', 'Auto PiP blocked (' + why + ')', e); }
    };
    try {
      navigator.mediaSession.setActionHandler('enterpictureinpicture', () => tryEnter('mediaSession'));
      NS.log('info', 'mediaSession auto-PiP handler registered');
    } catch (e) { NS.log('warn', 'enterpictureinpicture action unsupported', e); }

    document.addEventListener('visibilitychange', async () => {
      if (document.hidden) return tryEnter('visibility-hidden');
      if (autoEntered && document.pictureInPictureElement) {
        try { await document.exitPictureInPicture(); NS.log('info', 'Auto PiP closed - tab wapas aaya'); }
        catch (e) { NS.log('warn', 'auto exit failed', e); }
      }
      autoEntered = false;
    });
  };

  // ---- Keyboard command from background (Alt+P) ----
  try {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg && msg.type === 'toggle-pip') {
        NS.log('info', 'toggle-pip command received');
        NS.toggleNativePip().catch(e => NS.log('error', 'toggle-pip failed (gesture chahiye ho sakta hai)', e));
      }
    });
  } catch (e) {}
})();
