const DEFAULTS = { enabled: true, mode: 'button', sponsorblock: true, autoTrigger: true, debug: true, speed: 1, volume: 100 };
const $ = (id) => document.getElementById(id);

async function refreshCount() {
  const { logs = [] } = await chrome.storage.local.get('logs');
  $('count').textContent = `${logs.length} log lines stored`;
}

(async () => {
  const s = await chrome.storage.sync.get(DEFAULTS);
  for (const k of ['enabled', 'sponsorblock', 'autoTrigger', 'debug']) {
    $(k).checked = s[k];
    $(k).addEventListener('change', () => chrome.storage.sync.set({ [k]: $(k).checked }));
  }
  for (const k of ['mode']) {
    $(k).value = s[k];
    $(k).addEventListener('change', () => chrome.storage.sync.set({ [k]: $(k).value }));
  }
  refreshCount();

  $('download').addEventListener('click', async () => {
    const { logs = [] } = await chrome.storage.local.get('logs');
    const m = chrome.runtime.getManifest();
    const head = `Float Anything PiP v${m.version} - debug log\nUA: ${navigator.userAgent}\nExported: ${new Date().toISOString()}\n${'-'.repeat(60)}\n`;
    const body = logs.map(l =>
      `[${l.ts}] [${String(l.level).toUpperCase()}] [${l.src}] ${l.msg}` +
      (l.data !== undefined ? ' | ' + JSON.stringify(l.data) : '')).join('\n');
    const blob = new Blob([head + (body || 'No logs yet.')], { type: 'text/plain' });
    const a = document.createElement('a');
    const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    a.href = URL.createObjectURL(blob);
    a.download = `float-pip-debug-${stamp}.txt`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  });

  $('clear').addEventListener('click', async () => {
    await chrome.storage.local.set({ logs: [] });
    refreshCount();
  });
})();
