// YouTube: thumbnail click -> floating PiP, SponsorBlock on main player, auto-PiP.
(() => {
  const NS = window.__ytpip;
  if (!NS || NS.ytLoaded) return;
  NS.ytLoaded = true;
  const { log } = NS;

  NS.loadSettings().then(() => log('info', 'YouTube script ready', {
    url: location.href, version: chrome.runtime.getManifest().version,
    mode: NS.settings.mode, enabled: NS.settings.enabled
  }));
  NS.setupAutoPip();

  // Agar ye hamari popup window hai: chrome-less compact layout
  NS.inPopup = false;
  try {
    chrome.runtime.sendMessage({ type: 'isPopupWin' }).then((r) => {
      if (!r || !r.popup) return;
      NS.inPopup = true;
      document.documentElement.classList.add('ytpip-popup');
      log('info', 'Popup-window mode enabled');
    }).catch(() => {});
  } catch (e) {}

  const THUMB_SEL = 'ytd-thumbnail, yt-thumbnail-view-model, a#thumbnail, ytd-playlist-thumbnail, ytm-shorts-lockup-view-model, ytm-shorts-lockup-view-model-v2';
  const CARD_SEL = 'ytd-rich-item-renderer, ytd-video-renderer, ytd-compact-video-renderer, ytd-grid-video-renderer, yt-lockup-view-model, ytm-shorts-lockup-view-model, ytm-shorts-lockup-view-model-v2';
  const IMG_SEL = 'img, yt-image, canvas, yt-thumbnail-view-model, ytd-thumbnail';

  // Event path se video thumbnail dhundo (layout-independent):
  // known thumbnail container YA koi video-link jiske andar image ho.
  const findThumb = (path) => {
    let el = path.find(n => n.matches && n.matches(THUMB_SEL)) || null;
    let a = path.find(n => n.tagName === 'A' && n.href && NS.parseId(n.href)) || null;
    if (!a && el) {
      const card = el.closest(CARD_SEL);
      a = [...el.querySelectorAll('a[href]')].find(x => NS.parseId(x.href)) ||
          (card && [...card.querySelectorAll('a[href]')].find(x => NS.parseId(x.href))) || null;
    }
    if (!a) return null;
    if (!el) el = a.querySelector(IMG_SEL) ? (a.querySelector(IMG_SEL).closest('yt-thumbnail-view-model, ytd-thumbnail') || a) : null;
    if (!el) return null;                       // title/text link - thumbnail nahi
    const id = NS.parseId(a.href);
    const card = el.closest(CARD_SEL);
    const title = a.getAttribute('title') || a.getAttribute('aria-label') ||
      (card && card.querySelector('#video-title, h3')?.textContent?.trim()) || '';
    return { el, id, title };
  };

  // ---- Mode "button": thumbnail pe hover => chhota "Float" button ----
  let host, btn, target = null, hideT = 0, overBtn = false, shownLogs = 0, lastMove = 0;
  const hideBtn = () => { if (btn) btn.style.display = 'none'; target = null; };
  const scheduleHide = () => { clearTimeout(hideT); hideT = setTimeout(() => { if (!overBtn) hideBtn(); }, 300); };
  const place = (r) => {
    // top-left: YouTube ke apne buttons (Watch later/Queue) top-right me hote hain
    btn.style.top = Math.max(r.top, 0) + 6 + 'px';
    btn.style.left = Math.max(r.left, 0) + 6 + 'px';
  };
  const ensureBtn = () => {
    if (host) return;
    host = document.createElement('div');
    host.style.cssText = 'all:initial;position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647';
    const root = host.attachShadow({ mode: 'closed' });
    const style = document.createElement('style');
    style.textContent = `button{position:fixed;display:none;font:600 11px system-ui,sans-serif;color:#fff;background:rgba(20,20,20,.9);
      border:1px solid rgba(255,255,255,.4);border-radius:12px;padding:3px 9px;cursor:pointer;line-height:1.4;pointer-events:auto}
      button:hover{background:#f03;border-color:#f03}`;
    btn = document.createElement('button');
    btn.textContent = '⧉ Float';
    btn.title = 'Floating window me kholo';
    btn.addEventListener('mouseenter', () => { overBtn = true; clearTimeout(hideT); });
    btn.addEventListener('mouseleave', () => { overBtn = false; scheduleHide(); });
    btn.addEventListener('mousedown', (e) => { e.preventDefault(); e.stopPropagation(); });
    btn.addEventListener('click', (e) => {
      e.preventDefault(); e.stopPropagation();
      if (!target) return;
      const t = target;
      log('info', 'Float button click -> open', { id: t.id, title: t.title });
      hideBtn();
      NS.openVideo(t.id, t.title);           // real user click => gesture valid
    });
    root.append(style, btn);
    document.documentElement.append(host);
    log('info', 'Float button host created');
  };
  const show = (t) => {
    ensureBtn();
    target = t; clearTimeout(hideT);
    btn.style.display = 'block';
    place(t.el.getBoundingClientRect());
    if (shownLogs++ < 5) log('debug', 'Float button shown', { id: t.id });
  };

  // Pointer position based: YouTube ka hover-preview overlay thumbnail ke upar aa jata hai,
  // isliye element hierarchy pe nahi, thumbnail ke rectangle pe bharosa karte hain.
  document.addEventListener('mousemove', (e) => {
    const s = NS.settings;
    if (!s.enabled || s.mode !== 'button' || NS.inPopup) return;
    const now = performance.now();
    if (now - lastMove < 40) return;
    lastMove = now;
    if (target) {
      const r = target.el.getBoundingClientRect();
      const inside = e.clientX >= r.left - 4 && e.clientX <= r.right + 4 && e.clientY >= r.top - 4 && e.clientY <= r.bottom + 4;
      if (inside && r.width > 0) { clearTimeout(hideT); place(r); return; }
      if (overBtn) return;
    }
    const t = findThumb(e.composedPath());
    if (t) {
      const r = t.el.getBoundingClientRect();
      if (r.width >= 100 && r.height >= 50) { show(t); return; }
    }
    if (target) scheduleHide();
  }, { capture: true, passive: true });
  window.addEventListener('scroll', () => { if (target) hideBtn(); }, { passive: true, capture: true });

  // ---- Modes "always" / "alt": thumbnail click hi PiP kholta hai ----
  document.addEventListener('click', (e) => {
    const s = NS.settings;
    if (!s.enabled || s.mode === 'button' || NS.inPopup || e.defaultPrevented || e.button !== 0) return;
    if (e.ctrlKey || e.metaKey || e.shiftKey) return;        // normal behaviour bypass
    if (s.mode === 'alt' && !e.altKey) return;
    const t = findThumb(e.composedPath());
    if (!t) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    log('info', 'Thumbnail click -> open', { id: t.id, title: t.title });
    NS.openVideo(t.id, t.title);
  }, true);

  // CSS illusion: :picture-in-picture ke liye blur thumbnail variable
  const curId = () => new URL(location.href).searchParams.get('v');
  document.addEventListener('enterpictureinpicture', (e) => {
    if (!(e.target instanceof HTMLVideoElement)) return;
    const id = curId();
    if (id) document.documentElement.style.setProperty('--ytpip-thumb', `url(https://i.ytimg.com/vi/${id}/hqdefault.jpg)`);
    log('info', 'enterpictureinpicture', { id });
  }, true);
  document.addEventListener('leavepictureinpicture', (e) => {
    document.documentElement.style.removeProperty('--ytpip-thumb');
    log('info', 'leavepictureinpicture');
  }, true);

  // SponsorBlock on main player (native PiP me bhi kaam karta hai)
  let sbId = null, sbSegs = [], lastSkip = 0;
  document.addEventListener('timeupdate', (e) => {
    const v = e.target;
    if (!(v instanceof HTMLVideoElement) || !v.classList.contains('html5-main-video')) return;
    if (!NS.settings.sponsorblock || location.pathname !== '/watch') return;
    const id = curId();
    if (id !== sbId) {
      sbId = id; sbSegs = [];
      if (id) NS.getSegments(id).then(s => { if (sbId === id) sbSegs = s; });
      return;
    }
    if (!sbSegs.length || document.querySelector('.html5-video-player.ad-showing')) return;
    const now = Date.now();
    for (const s of sbSegs) {
      const [a, b] = s.segment;
      if (v.currentTime >= a && v.currentTime < b - 0.5 && now - lastSkip > 1500) {
        lastSkip = now; v.currentTime = b;
        log('info', 'SponsorBlock skip (main player)', { category: s.category, from: a, to: b });
        break;
      }
    }
  }, true);
})();
