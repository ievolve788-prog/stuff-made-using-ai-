// Baaki websites: (1) hover "Float" button -> native PiP, (2) Alt+Click on YouTube-link thumbnail -> floating player.
(() => {
  const NS = window.__ytpip;
  if (!NS || NS.genLoaded) return;
  NS.genLoaded = true;
  const { log } = NS;

  NS.loadSettings().then(() => log('info', 'Generic script ready'));
  NS.setupAutoPip();

  // (2) Alt+Click on thumbnails that link to YouTube (Google, Reddit, blogs...)
  document.addEventListener('click', (e) => {
    if (!NS.settings.enabled || !e.altKey || e.button !== 0) return;
    const a = e.composedPath().find(n => n.tagName === 'A' && n.href);
    if (!a) return;
    const id = NS.parseId(a.href);
    if (!id || !a.querySelector('img,picture,video')) return;
    e.preventDefault(); e.stopImmediatePropagation();
    log('info', 'Alt+click YouTube link -> PiP', { id });
    NS.openVideo(id, a.getAttribute('title') || '');
  }, true);

  // (1) Hover button over any <video>
  let host, btn, cur = null, hideT = 0, overBtn = false;
  const ensureBtn = () => {
    if (host) return;
    host = document.createElement('div');
    host.style.cssText = 'all:initial;position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647';
    const root = host.attachShadow({ mode: 'closed' });
    const style = document.createElement('style');
    style.textContent = `button{position:fixed;display:none;font:600 12px system-ui,sans-serif;color:#fff;background:rgba(20,20,20,.85);
      border:1px solid rgba(255,255,255,.35);border-radius:14px;padding:4px 10px;cursor:pointer}button:hover{background:#f03}`;
    btn = document.createElement('button');
    btn.textContent = '⧉ Float';
    btn.addEventListener('mouseenter', () => { overBtn = true; clearTimeout(hideT); });
    btn.addEventListener('mouseleave', () => { overBtn = false; scheduleHide(); });
    btn.addEventListener('mousedown', (e) => e.preventDefault());
    btn.addEventListener('click', async (e) => {
      e.preventDefault(); e.stopPropagation();
      if (!cur) return;
      try {
        if (document.pictureInPictureElement === cur) await document.exitPictureInPicture();
        else await NS.enterNativePip(cur, 'hover-button');
      } catch (err) { log('error', 'Hover PiP failed', err); }
    });
    root.append(style, btn);
    (document.documentElement || document.body).append(host);
  };
  const scheduleHide = () => { clearTimeout(hideT); hideT = setTimeout(() => { if (btn) btn.style.display = 'none'; }, 1500); };

  let last = 0;
  document.addEventListener('mousemove', (e) => {
    const now = performance.now();
    if (now - last < 120) return;
    last = now;
    if (!NS.settings.enabled) return;
    const v = document.elementsFromPoint(e.clientX, e.clientY).find(n => n instanceof HTMLVideoElement);
    if (v && v.videoWidth > 0) {
      const r = v.getBoundingClientRect();
      if (r.width < 200 || r.height < 110) return;
      ensureBtn(); cur = v; clearTimeout(hideT);
      btn.style.display = 'block';
      btn.style.top = Math.max(r.top, 0) + 8 + 'px';
      btn.style.left = Math.max(Math.min(r.right, innerWidth) - 78, 0) + 'px';
      scheduleHide();
    }
  }, { passive: true });
})();
