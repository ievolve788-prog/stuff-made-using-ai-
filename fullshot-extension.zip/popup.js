const $ = (id) => document.getElementById(id);
const msg = (t) => ($('msg').textContent = t);

async function start(mode) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  await chrome.runtime.sendMessage({ cmd: 'start', mode, tabId: tab.id });
  window.close();
}
$('full').onclick = () => start('full');
$('visible').onclick = () => start('visible');
$('region').onclick = () => start('region');

$('copylog').onclick = async () => {
  const text = await chrome.runtime.sendMessage({ cmd: 'getLog' });
  try {
    await navigator.clipboard.writeText(text);
    msg('Copied ' + text.split('\n').length + ' lines to clipboard');
  } catch (e) {
    chrome.runtime.sendMessage({ cmd: 'log', level: 'warn', msg: '[popup] clipboard failed', data: { message: e.message } });
    $('ta').style.display = 'block';
    $('ta').value = text;
    $('ta').select();
    msg('Clipboard blocked: select all and copy manually');
  }
};
$('clearlog').onclick = async () => {
  await chrome.runtime.sendMessage({ cmd: 'clearLog' });
  msg('Log cleared');
};
