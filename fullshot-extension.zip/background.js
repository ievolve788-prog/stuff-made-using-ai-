const MAX_HEIGHT = 50000; // CSS px cap for endless-scroll pages
const MAX_LOG = 500;
const pending = new Map();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* ---------------- debug log (persisted in chrome.storage.session) ---------------- */
let logBuf = [];
const ready = chrome.storage.session
  .get('log')
  .then((r) => { logBuf = (r.log || []).concat(logBuf); })
  .catch(() => {});
const errInfo = (e) => ({
  message: String((e && e.message) || e),
  stack: e && e.stack ? String(e.stack).split('\n').slice(0, 4).join(' | ') : undefined,
});
function log(level, msg, data) {
  logBuf.push({ t: new Date().toISOString(), level, msg, data });
  if (logBuf.length > MAX_LOG) logBuf.splice(0, logBuf.length - MAX_LOG);
  (level === 'error' ? console.error : console.log)('[FullShot]', msg, data ?? '');
  ready.then(() => chrome.storage.session.set({ log: logBuf })).catch(() => {});
}
function formatLog() {
  const m = chrome.runtime.getManifest();
  const head = [
    '=== FullShot debug log ===',
    'Version: ' + m.version,
    'Browser: ' + navigator.userAgent,
    'Generated: ' + new Date().toISOString(),
    'Entries: ' + logBuf.length,
    '---',
  ];
  const lines = logBuf.map(
    (e) => `[${e.t}] ${e.level.toUpperCase()} ${e.msg}${e.data !== undefined ? ' ' + JSON.stringify(e.data) : ''}`
  );
  return head.concat(lines).join('\n');
}
const host = (u) => { try { return new URL(u).hostname; } catch (_) { return '(unknown)'; } };
log('info', 'service worker started');

/* ---------------- functions injected into the page ---------------- */
function prep() {
  const st = document.createElement('style');
  st.id = '__fullshot_style';
  st.textContent = '::-webkit-scrollbar{display:none!important}*{scrollbar-width:none!important}html{scroll-behavior:auto!important}';
  document.documentElement.appendChild(st);
  const de = document.documentElement, vw = innerWidth, vh = innerHeight;
  const docTotal = Math.max(de.scrollHeight, document.body ? document.body.scrollHeight : 0);
  let el = null, best = 0;
  // If the document itself doesn't scroll, look for the biggest inner scroll container
  if (docTotal <= vh + 8) {
    for (const e of document.querySelectorAll('*')) {
      if (e.scrollHeight <= e.clientHeight + 8) continue;
      const oy = getComputedStyle(e).overflowY;
      if (oy !== 'auto' && oy !== 'scroll' && oy !== 'overlay') continue;
      const r = e.getBoundingClientRect();
      const w = Math.min(r.right, vw) - Math.max(r.left, 0);
      const h = Math.min(r.bottom, vh) - Math.max(r.top, 0);
      if (w > 0 && h > 0 && w * h > best && w * h >= vw * vh * 0.2) { best = w * h; el = e; }
    }
  }
  const base = { vw, vh, sx: scrollX, sy: scrollY, title: document.title };
  if (!el) return { ...base, mode: 'window', rect: { x: 0, y: 0, w: vw, h: vh }, total: docTotal };
  el.setAttribute('data-fullshot-target', '1');
  const r = el.getBoundingClientRect();
  const x = Math.max(0, r.left + el.clientLeft), y = Math.max(0, r.top + el.clientTop);
  return {
    ...base, mode: 'element',
    rect: { x, y, w: Math.min(el.clientWidth, vw - x), h: Math.min(el.clientHeight, vh - y) },
    total: el.scrollHeight, st: el.scrollTop,
    target: el.tagName.toLowerCase() + (el.id ? '#' + el.id : ''),
  };
}
function scrollStep(y, hideFixed, isEl) {
  const t = isEl ? document.querySelector('[data-fullshot-target]') : null;
  if (hideFixed && !window.__fullshotHidden) {
    window.__fullshotHidden = [];
    for (const e of document.querySelectorAll('*')) {
      const p = getComputedStyle(e).position;
      if ((p === 'fixed' || p === 'sticky') && !(t && e.contains(t))) {
        window.__fullshotHidden.push([e, e.style.getPropertyValue('visibility'), e.style.getPropertyPriority('visibility')]);
        e.style.setProperty('visibility', 'hidden', 'important');
      }
    }
  }
  if (t) { t.scrollTop = y; return Math.round(t.scrollTop); }
  window.scrollTo(0, y);
  return Math.round(window.scrollY);
}
function restore(sx, sy, st, isEl) {
  (window.__fullshotHidden || []).forEach(([e, v, pr]) => {
    if (v) e.style.setProperty('visibility', v, pr); else e.style.removeProperty('visibility');
  });
  window.__fullshotHidden = null;
  const t = document.querySelector('[data-fullshot-target]');
  if (t) { if (isEl) t.scrollTop = st; t.removeAttribute('data-fullshot-target'); }
  const s = document.getElementById('__fullshot_style');
  if (s) s.remove();
  window.scrollTo(sx, sy);
}
function selector() {
  if (document.getElementById('__fullshot_overlay')) return;
  const ov = document.createElement('div');
  ov.id = '__fullshot_overlay';
  ov.style.cssText = 'position:fixed;inset:0;z-index:2147483647;cursor:crosshair;background:rgba(0,0,0,.3);';
  const box = document.createElement('div');
  box.style.cssText = 'position:fixed;display:none;border:2px solid #4f46e5;box-sizing:border-box;pointer-events:none;box-shadow:0 0 0 100vmax rgba(0,0,0,.45);';
  const tip = document.createElement('div');
  tip.textContent = 'Drag to select an area \u00b7 Esc to cancel';
  tip.style.cssText = 'position:fixed;top:12px;left:50%;transform:translateX(-50%);background:#222;color:#fff;font:13px system-ui,sans-serif;padding:6px 12px;border-radius:6px;pointer-events:none;';
  ov.append(box, tip);
  let sx = 0, sy = 0, down = false;
  const rectOf = (e) => ({ x: Math.min(sx, e.clientX), y: Math.min(sy, e.clientY), w: Math.abs(e.clientX - sx), h: Math.abs(e.clientY - sy) });
  const onKey = (e) => { if (e.key === 'Escape') { e.preventDefault(); finish(null); } };
  const finish = (rect) => {
    document.removeEventListener('keydown', onKey, true);
    ov.remove();
    chrome.runtime.sendMessage(
      rect && rect.w > 4 && rect.h > 4
        ? { cmd: 'region', rect, vw: innerWidth, title: document.title }
        : { cmd: 'regionCancel' }
    );
  };
  ov.addEventListener('mousedown', (e) => {
    e.preventDefault(); down = true; sx = e.clientX; sy = e.clientY;
    ov.style.background = 'transparent'; box.style.display = 'block';
  });
  ov.addEventListener('mousemove', (e) => {
    if (!down) return;
    const r = rectOf(e);
    Object.assign(box.style, { left: r.x + 'px', top: r.y + 'px', width: r.w + 'px', height: r.h + 'px' });
  });
  ov.addEventListener('mouseup', (e) => { if (down) finish(rectOf(e)); });
  document.addEventListener('keydown', onKey, true);
  document.documentElement.appendChild(ov);
}

/* ---------------- capture logic ---------------- */
let busy = false, lastCapture = 0;
const badge = (tabId, text, color) => {
  if (color) chrome.action.setBadgeBackgroundColor({ color });
  chrome.action.setBadgeText({ tabId, text }).catch(() => {});
};

async function grab(windowId) {
  const wait = 600 - (Date.now() - lastCapture); // Chrome allows ~2 captures/second
  if (wait > 0) await sleep(wait);
  for (let a = 1; ; a++) {
    try {
      const img = await chrome.tabs.captureVisibleTab(windowId, { format: 'png' });
      lastCapture = Date.now();
      return img;
    } catch (e) {
      if (a < 4 && /quota|MAX_CAPTURE/i.test(e.message)) {
        log('warn', 'capture rate-limited, retrying', { attempt: a });
        await sleep(700);
        continue;
      }
      throw e;
    }
  }
}

async function openViewer(data, tab) {
  const id = crypto.randomUUID();
  pending.set(id, data);
  await chrome.tabs.create({ url: chrome.runtime.getURL('viewer.html?id=' + id), index: tab.index + 1 });
  log('info', 'viewer opened', { mode: data.mode, frames: data.frames.length, total: data.total, rect: data.rect });
}

async function fullPage(tab) {
  const run = (func, args = []) =>
    chrome.scripting.executeScript({ target: { tabId: tab.id }, func, args }).then((r) => r[0].result);
  const t0 = Date.now();
  let meta;
  try {
    meta = await run(prep);
    log('info', 'page measured', { mode: meta.mode, target: meta.target, vw: meta.vw, vh: meta.vh, total: meta.total, rect: meta.rect });
    const step = Math.floor(meta.rect.h);
    if (step < 50) throw new Error('Scroll area too small (' + step + 'px)');
    const total = Math.min(meta.total, MAX_HEIGHT);
    if (meta.total > MAX_HEIGHT) log('warn', 'page capped', { real: meta.total, cap: MAX_HEIGHT });
    const ys = [];
    for (let y = 0; y < total - step; y += step) ys.push(y);
    ys.push(Math.max(0, total - step));

    const frames = [];
    for (let i = 0; i < ys.length; i++) {
      const y = await run(scrollStep, [ys[i], i > 0, meta.mode === 'element']);
      await sleep(250); // let lazy content settle
      const img = await grab(tab.windowId);
      frames.push({ y, img });
      log('info', 'frame captured', { i: i + 1, of: ys.length, requestedY: ys[i], actualY: y });
    }
    await openViewer({ frames, w: meta.vw, rect: meta.rect, total, title: meta.title, mode: meta.mode }, tab);
    log('info', 'full capture done', { ms: Date.now() - t0 });
    badge(tab.id, '');
  } catch (e) {
    log('error', 'full capture failed', errInfo(e));
    badge(tab.id, 'ERR', '#d33');
    setTimeout(() => badge(tab.id, ''), 4000);
  } finally {
    if (meta) await run(restore, [meta.sx, meta.sy, meta.st, meta.mode === 'element']).catch((e) => log('warn', 'restore failed', errInfo(e)));
  }
}

async function visibleArea(tab) {
  try {
    const [{ result: m }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => ({ w: innerWidth, h: innerHeight, title: document.title }),
    });
    const img = await grab(tab.windowId);
    await openViewer({ frames: [{ y: 0, img }], w: m.w, rect: { x: 0, y: 0, w: m.w, h: m.h }, total: m.h, title: m.title, mode: 'visible' }, tab);
  } catch (e) {
    log('error', 'visible capture failed', errInfo(e));
    badge(tab.id, 'ERR', '#d33');
    setTimeout(() => badge(tab.id, ''), 4000);
  }
}

async function startCapture(tabId, mode) {
  if (busy) { log('warn', 'capture already running, ignored', { mode }); return; }
  busy = true;
  try {
    const tab = await chrome.tabs.get(tabId);
    log('info', 'start', { mode, host: host(tab.url) });
    if (mode === 'full') { badge(tabId, '…', '#4f46e5'); await fullPage(tab); }
    else if (mode === 'visible') await visibleArea(tab);
    else if (mode === 'region') {
      await chrome.scripting.executeScript({ target: { tabId }, func: selector });
      log('info', 'region selector shown');
    }
  } catch (e) {
    log('error', 'start failed', errInfo(e));
    badge(tabId, 'ERR', '#d33');
    setTimeout(() => badge(tabId, ''), 4000);
  } finally {
    busy = false;
  }
}

async function handleRegion(msg, tab) {
  try {
    await sleep(150); // let the page repaint without the overlay
    const img = await grab(tab.windowId);
    log('info', 'region selected', msg.rect);
    await openViewer({ frames: [{ y: 0, img }], w: msg.vw, rect: msg.rect, total: msg.rect.h, title: msg.title, mode: 'region' }, tab);
  } catch (e) {
    log('error', 'region capture failed', errInfo(e));
    badge(tab.id, 'ERR', '#d33');
    setTimeout(() => badge(tab.id, ''), 4000);
  }
}

/* ---------------- wiring ---------------- */
chrome.runtime.onMessage.addListener((msg, sender, send) => {
  switch (msg.cmd) {
    case 'start': send({ ok: true }); startCapture(msg.tabId, msg.mode); break;
    case 'region': send({ ok: true }); handleRegion(msg, sender.tab); break;
    case 'regionCancel': log('info', 'region selection cancelled'); send({ ok: true }); break;
    case 'log': log(msg.level || 'info', msg.msg, msg.data); break;
    case 'getLog': ready.then(() => send(formatLog())); return true;
    case 'clearLog': logBuf = []; chrome.storage.session.set({ log: [] }); log('info', 'log cleared'); send({ ok: true }); break;
  }
});

chrome.commands.onCommand.addListener(async (cmd) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  if (cmd === 'capture-full') startCapture(tab.id, 'full');
  if (cmd === 'capture-region') startCapture(tab.id, 'region');
});

chrome.runtime.onConnect.addListener((port) => {
  const d = pending.get(port.name);
  pending.delete(port.name);
  if (!d) {
    port.postMessage({ type: 'error', error: 'Capture data expired. Please capture again.' });
    log('error', 'viewer connected but no data was pending');
    return;
  }
  try {
    const { frames, ...meta } = d;
    port.postMessage({ type: 'meta', ...meta, count: frames.length });
    frames.forEach((f, i) => port.postMessage({ type: 'frame', i, y: f.y, img: f.img })); // one message per frame
    port.postMessage({ type: 'done' });
  } catch (e) {
    log('error', 'sending frames to viewer failed', errInfo(e));
  }
});
