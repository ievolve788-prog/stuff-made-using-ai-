const MAX = 16000; // device px per canvas (Chrome canvas limit is ~16k)
const $ = (id) => document.getElementById(id);
const out = $('out'), statusEl = $('status');
let canvases = [], scale = 1, name = 'screenshot', meta = null;
const frames = [];

const vlog = (level, msg, data) => {
  try { chrome.runtime.sendMessage({ cmd: 'log', level, msg: '[viewer] ' + msg, data }).catch(() => {}); } catch (_) {}
};
const say = (t) => {
  $('toast').textContent = t;
  clearTimeout(say.t);
  say.t = setTimeout(() => ($('toast').textContent = ''), 5000);
};
window.addEventListener('error', (e) => vlog('error', e.message));
window.addEventListener('unhandledrejection', (e) => vlog('error', 'unhandled rejection', { reason: String(e.reason) }));

const port = chrome.runtime.connect({ name: new URLSearchParams(location.search).get('id') });
port.onMessage.addListener(async (m) => {
  if (m.type === 'error') { statusEl.textContent = m.error; return; }
  if (m.type === 'meta') { meta = m; return; }
  if (m.type === 'frame') {
    frames[m.i] = m;
    statusEl.textContent = `Receiving frames… ${frames.filter(Boolean).length}/${meta.count}`;
    return;
  }
  if (m.type === 'done') {
    try { await render(); }
    catch (e) { statusEl.textContent = 'Failed to build image: ' + e.message; vlog('error', 'render failed', { message: e.message }); }
  }
});

async function render() {
  statusEl.textContent = 'Stitching screenshot…';
  $('title').textContent = meta.title || 'Screenshot';
  name = 'screenshot-' + new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
  const bmps = await Promise.all(frames.map(async (f) => createImageBitmap(await (await fetch(f.img)).blob())));
  scale = bmps[0].width / meta.w;
  const r = meta.rect;
  const cw = Math.round(r.w * scale), totalPx = Math.round(meta.total * scale);
  const sx = Math.round(r.x * scale), sy = Math.round(r.y * scale), srcH = Math.round(r.h * scale);

  for (let start = 0; start < totalPx; start += MAX) {
    const c = document.createElement('canvas');
    c.width = cw;
    c.height = Math.min(MAX, totalPx - start);
    const ctx = c.getContext('2d');
    frames.forEach((f, i) => {
      const b = bmps[i];
      const sw = Math.min(cw, b.width - sx), sh = Math.min(srcH, b.height - sy);
      const dy = Math.round(f.y * scale) - start;
      if (dy < c.height && dy + sh > 0) ctx.drawImage(b, sx, sy, sw, sh, 0, dy, sw, sh);
    });
    canvases.push(c);
    out.appendChild(c);
  }
  statusEl.remove();
  ['png', 'jpg', 'pdf', 'copy'].forEach((id) => ($(id).disabled = false));
  vlog('info', 'rendered', { mode: meta.mode, parts: canvases.length, widthPx: cw, heightPx: totalPx, scale });
}

const toBlob = (c, type, q) => new Promise((res) => c.toBlob(res, type, q));
function save(blob, filename) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}
async function saveImages(type, ext, q) {
  for (let i = 0; i < canvases.length; i++) {
    const suffix = canvases.length > 1 ? '-' + (i + 1) : '';
    save(await toBlob(canvases[i], type, q), name + suffix + '.' + ext);
    await new Promise((r) => setTimeout(r, 300));
  }
  vlog('info', 'saved', { ext, parts: canvases.length });
}
$('png').onclick = () => saveImages('image/png', 'png');
$('jpg').onclick = () => saveImages('image/jpeg', 'jpg', 0.92);
$('pdf').onclick = async () => {
  try {
    const pages = [];
    for (const c of canvases) {
      const blob = await toBlob(c, 'image/jpeg', 0.92);
      pages.push({ w: c.width, h: c.height, jpeg: new Uint8Array(await blob.arrayBuffer()) });
    }
    save(buildPdf(pages), name + '.pdf');
    vlog('info', 'saved pdf', { pages: pages.length });
  } catch (e) { say('PDF failed: ' + e.message); vlog('error', 'pdf failed', { message: e.message }); }
};
$('copy').onclick = async () => {
  try {
    const blob = await toBlob(canvases[0], 'image/png');
    await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
    say(canvases.length > 1 ? `Copied part 1 of ${canvases.length} (too tall for one image)` : 'Image copied to clipboard');
    vlog('info', 'image copied', { parts: canvases.length });
  } catch (e) { say('Copy failed: ' + e.message); vlog('error', 'copy image failed', { message: e.message }); }
};
$('copylog').onclick = async () => {
  try {
    const text = await chrome.runtime.sendMessage({ cmd: 'getLog' });
    await navigator.clipboard.writeText(text);
    say('Debug log copied (' + text.split('\n').length + ' lines)');
  } catch (e) { say('Log copy failed: ' + e.message); }
};

// Minimal PDF writer: one JPEG per page, page sized to the image
function buildPdf(pages) {
  const enc = new TextEncoder();
  const parts = [], offs = [];
  let len = 0;
  const push = (b) => { if (typeof b === 'string') b = enc.encode(b); parts.push(b); len += b.length; };
  const obj = (n, fn) => { offs[n] = len; push(n + ' 0 obj\n'); fn(); push('\nendobj\n'); };
  const n = pages.length, total = 2 + 3 * n;
  push('%PDF-1.4\n');
  obj(1, () => push('<</Type/Catalog/Pages 2 0 R>>'));
  obj(2, () => push(`<</Type/Pages/Count ${n}/Kids[${pages.map((_, i) => `${3 + 3 * i} 0 R`).join(' ')}]>>`));
  pages.forEach((p, i) => {
    const pg = 3 + 3 * i, ct = pg + 1, im = pg + 2;
    const W = ((p.w / scale) * 0.75).toFixed(2), H = ((p.h / scale) * 0.75).toFixed(2);
    const content = `q ${W} 0 0 ${H} 0 0 cm /Im0 Do Q`;
    obj(pg, () => push(`<</Type/Page/Parent 2 0 R/MediaBox[0 0 ${W} ${H}]/Resources<</XObject<</Im0 ${im} 0 R>>>>/Contents ${ct} 0 R>>`));
    obj(ct, () => push(`<</Length ${content.length}>>\nstream\n${content}\nendstream`));
    obj(im, () => {
      push(`<</Type/XObject/Subtype/Image/Width ${p.w}/Height ${p.h}/ColorSpace/DeviceRGB/BitsPerComponent 8/Filter/DCTDecode/Length ${p.jpeg.length}>>\nstream\n`);
      push(p.jpeg);
      push('\nendstream');
    });
  });
  const xr = len;
  push(`xref\n0 ${total + 1}\n0000000000 65535 f \n`);
  for (let i = 1; i <= total; i++) push(String(offs[i]).padStart(10, '0') + ' 00000 n \n');
  push(`trailer\n<</Size ${total + 1}/Root 1 0 R>>\nstartxref\n${xr}\n%%EOF`);
  return new Blob(parts, { type: 'application/pdf' });
}
