# Anki Reviewer (Chrome extension)

Review your Anki cards in a Chrome tab. Talks to Anki Desktop through AnkiConnect.

## Setup
1. Install the **AnkiConnect** add-on in Anki Desktop (Tools → Add-ons → Get Add-ons → code `2055492159`), then restart Anki.
2. In Chrome open `chrome://extensions`, enable **Developer mode**, click **Load unpacked**, and select this folder.
3. Keep Anki Desktop open, then click the extension icon.
4. If connecting fails, the page shows the exact origin line to add to AnkiConnect's `webCorsOriginList`
   (Tools → Add-ons → AnkiConnect → Config), then restart Anki.

## Features
- Pick a deck (or all decks); optionally add up to N new cards to the session.
- Show answer, rate Again / Hard / Good / Easy (scheduling is handled by Anki).
- **Suspend** a card (with undo), **Delete** the note (with confirmation), or Skip.
- **Debug mode**: toggle in the header to show a log of every AnkiConnect request/response,
  timings, errors, and media loading. Copy or clear the log from the panel. Errors are always
  written to the browser console; debug mode adds verbose output.

## Shortcuts
Space = show answer / Good, 1-4 = rate, S = suspend, U = undo suspend, D = delete note, K = skip.

## Limitations
- Anki Desktop must be running. Audio playback isn't supported (audio tags are stripped); images are.
- Reviews are recorded in your local Anki collection; sync from Anki Desktop as usual.
- Deleting removes the whole note and all its cards.

## Options (header checkboxes, remembered between sessions)
- **Random order**: shuffles the queue each time you press Start / reload (takes effect on the next load).
- **Always open in new tab**: the toolbar icon opens a fresh review tab every click. When off, it focuses the existing review tab if one is open.
- **Debug**: shows the request/response log panel.
- **Open on every new tab**: any new browser tab (Ctrl+T) opens the review page instead of Chrome's New Tab page. Turn it off to go back to normal. If the page doesn't respond to keys right away, click on it once (Chrome may keep focus in the address bar).
