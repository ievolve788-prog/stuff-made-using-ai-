const REVIEW_URL = chrome.runtime.getURL('review.html');

// Toolbar icon: open the review page.
// If "Always open in new tab" is on, a fresh tab is opened every time;
// otherwise an already-open review tab is focused (default).
chrome.action.onClicked.addListener(async () => {
  const { alwaysNewTab } = await chrome.storage.local.get({ alwaysNewTab: false });
  if (!alwaysNewTab) {
    const existing = await chrome.tabs.query({ url: REVIEW_URL });
    if (existing.length) {
      await chrome.tabs.update(existing[0].id, { active: true });
      await chrome.windows.update(existing[0].windowId, { focused: true });
      return;
    }
  }
  await chrome.tabs.create({ url: REVIEW_URL });
});

// "Open on every new tab": when on, any brand-new tab that would show the
// browser's New Tab page is redirected to the review page. This is done with a
// listener (not a manifest override) so it can be switched on and off.
const NEW_TAB_PREFIXES = [
  'chrome://newtab',
  'chrome://new-tab-page',
  'chrome-search://local-ntp',
  'edge://newtab',
];

chrome.tabs.onCreated.addListener(async (tab) => {
  try {
    const { reviewOnNewTab } = await chrome.storage.local.get({ reviewOnNewTab: false });
    if (!reviewOnNewTab) return;
    const url = tab.pendingUrl || tab.url || '';
    if (NEW_TAB_PREFIXES.some((p) => url.startsWith(p))) {
      await chrome.tabs.update(tab.id, { url: REVIEW_URL });
    }
  } catch (e) {
    console.error('[anki] new-tab redirect failed', e);
  }
});
