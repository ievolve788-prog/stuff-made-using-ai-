'use strict';

const ANKI_URL = 'http://127.0.0.1:8765';
const $ = (id) => document.getElementById(id);

const state = {
  queue: [],
  idx: 0,
  info: null,
  answerShown: false,
  debug: false,
  busy: false,
  lastSuspended: null,
  stats: { reviewed: 0, suspended: 0, deleted: 0, skipped: 0 },
};

/* ---------------------------------------------------------------- logging */

const logBuffer = [];
let logRenderQueued = false;

function short(v, n = 400) {
  let s;
  try { s = typeof v === 'string' ? v : JSON.stringify(v); } catch { s = String(v); }
  return s.length > n ? `${s.slice(0, n)}… (${s.length} chars)` : s;
}

function log(level, msg, data, max) {
  logBuffer.push({ t: new Date().toISOString().slice(11, 23), level, msg, data, max });
  if (logBuffer.length > 1000) logBuffer.shift();
  if (state.debug || level === 'error') {
    const fn = level === 'error' ? console.error : console.debug;
    if (data === undefined) fn('[anki]', msg); else fn('[anki]', msg, data);
  }
  if (!logRenderQueued) {
    logRenderQueued = true;
    requestAnimationFrame(() => { logRenderQueued = false; renderLog(); });
  }
}

function renderLog() {
  if (!state.debug) return;
  const el = $('logOutput');
  el.textContent = logBuffer
    .map((e) => `${e.t} ${e.level.toUpperCase().padEnd(5)} ${e.msg}${e.data !== undefined ? ' ' + short(e.data, e.max || 400) : ''}`)
    .join('\n');
  el.scrollTop = el.scrollHeight;
}

function applyDebug() {
  $('debugPanel').hidden = !state.debug;
  renderLog();
}

window.addEventListener('error', (e) => log('error', `Uncaught: ${e.message}`, `${e.filename}:${e.lineno}`));
window.addEventListener('unhandledrejection', (e) => log('error', `Unhandled rejection: ${e.reason && e.reason.message || e.reason}`));

/* -------------------------------------------------------------- AnkiConnect */

async function invoke(action, params = {}) {
  const body = JSON.stringify({ action, version: 6, params });
  const t0 = performance.now();
  log('debug', `→ ${action}`, params);

  let res;
  try {
    res = await fetch(ANKI_URL, { method: 'POST', body });
  } catch (e) {
    log('error', `Network error on "${action}": ${e.message}`);
    const err = new Error('Cannot reach AnkiConnect');
    err.code = 'NETWORK';
    throw err;
  }
  if (!res.ok) {
    log('error', `HTTP ${res.status} on "${action}"`);
    throw new Error(`AnkiConnect returned HTTP ${res.status}`);
  }

  let json;
  try { json = await res.json(); } catch (e) {
    log('error', `Bad JSON from "${action}": ${e.message}`);
    throw new Error('AnkiConnect returned invalid JSON');
  }
  const ms = Math.round(performance.now() - t0);
  if (json.error) {
    log('error', `✗ ${action} (${ms}ms): ${json.error}`);
    throw new Error(json.error);
  }
  log('debug', `← ${action} (${ms}ms)`, json.result);
  return json.result;
}

/* ------------------------------------------------------------------ helpers */

function toast(msg) {
  const t = $('toast');
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(toast._h);
  toast._h = setTimeout(() => { t.hidden = true; }, 2200);
}

function escapeSearch(s) { return s.replace(/[\\"*_]/g, '\\$&'); }

function stripHtml(html) {
  const d = new DOMParser().parseFromString(html || '', 'text/html');
  return (d.body.textContent || '').trim();
}

function firstFieldText(info) {
  const fields = Object.values(info.fields || {}).sort((a, b) => a.order - b.order);
  return stripHtml(fields[0] ? fields[0].value : '').slice(0, 100) || '(empty)';
}

const MIME = {
  png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif',
  webp: 'image/webp', svg: 'image/svg+xml', bmp: 'image/bmp', avif: 'image/avif',
};
const mediaCache = new Map();

async function mediaToDataUri(name) {
  if (mediaCache.has(name)) return mediaCache.get(name);
  let filename = name;
  try { filename = decodeURIComponent(name); } catch { /* keep raw */ }
  let uri = null;
  try {
    const b64 = await invoke('retrieveMediaFile', { filename });
    if (b64) {
      const ext = filename.split('.').pop().toLowerCase();
      uri = `data:${MIME[ext] || 'application/octet-stream'};base64,${b64}`;
    } else {
      log('warn', `Media file not found: ${filename}`);
    }
  } catch (e) {
    log('warn', `Could not load media "${filename}": ${e.message}`);
  }
  mediaCache.set(name, uri);
  return uri;
}

async function inlineMedia(html) {
  const re = /(<img[^>]*?\ssrc=)(["'])([^"']+)\2/gi;
  const names = new Set();
  for (const m of html.matchAll(re)) {
    if (!/^(https?:|data:|blob:)/i.test(m[3])) names.add(m[3]);
  }
  const map = new Map();
  for (const n of names) map.set(n, await mediaToDataUri(n));
  return html.replace(re, (all, pre, q, src) => (map.get(src) ? `${pre}${q}${map.get(src)}${q}` : all));
}

/* ----------------------------------------------------------------- rendering */

async function renderHtml(html) {
  // Audio isn't supported; strip the placeholders so they don't show as text.
  const audioTags = html.match(/\[(sound|anki:play)[^\]]*\]/g);
  if (audioTags) log('info', `Stripped ${audioTags.length} audio tag(s) (audio not supported)`, audioTags);
  html = html.replace(/\[(sound|anki:play)[^\]]*\]/g, '');
  const scriptCount = (html.match(/<script/gi) || []).length;
  if (scriptCount) {
    log('warn', `Card has ${scriptCount} <script> tag(s). Scripts are disabled in this viewer, so JS-drawn layouts (e.g. new-style Image Occlusion) may not render.`);
  }
  log('debug', 'Raw card HTML (before media inlining)', html, 2500);
  html = await inlineMedia(html);

  const css = (state.info && state.info.css) || '';
  const frame = $('cardFrame');
  frame.onload = () => {
    const resize = () => {
      try {
        const doc = frame.contentDocument;
        frame.style.height = `${Math.max(220, doc.documentElement.scrollHeight)}px`;
      } catch (e) { log('warn', `Could not resize card frame: ${e.message}`); }
    };
    resize();
    try { for (const img of frame.contentDocument.images) img.addEventListener('load', resize); } catch { /* ignore */ }
  };
  frame.srcdoc = `<!doctype html><html><head><meta charset="utf-8">
<style>body{margin:0;padding:12px}img{max-width:100%}${css}</style></head>
<body><div class="card">${html}</div></body></html>`;
}

function updateUI() {
  const info = state.info;
  $('deckName').textContent = info ? info.deckName : '';
  $('progress').textContent = `Card ${state.idx + 1} of ${state.queue.length}`;
  $('showRow').hidden = state.answerShown;
  $('rateRow').hidden = !state.answerShown;
  $('undoSuspendBtn').hidden = state.lastSuspended == null;
  $('cardPanel').hidden = false;
  $('donePanel').hidden = true;
}

function showDone() {
  const s = state.stats;
  $('cardPanel').hidden = true;
  $('donePanel').hidden = false;
  $('doneStats').textContent =
    `Reviewed ${s.reviewed} · suspended ${s.suspended} · deleted ${s.deleted} · skipped ${s.skipped}`;
  state.info = null;
}

async function showCard() {
  while (state.idx < state.queue.length) {
    const id = state.queue[state.idx];
    const [info] = await invoke('cardsInfo', { cards: [id] });
    if (info && info.cardId) {
      state.info = info;
      state.answerShown = false;
      await renderHtml(info.question);
      updateUI();
      return;
    }
    log('info', `Card ${id} no longer exists (deleted?), skipping`);
    state.idx++;
  }
  showDone();
}

/* ------------------------------------------------------------------ actions */

async function run(label, fn) {
  if (state.busy) { log('debug', `Ignored "${label}" while busy`); return; }
  state.busy = true;
  document.querySelectorAll('button').forEach((b) => { b.disabled = true; });
  try {
    await fn();
  } catch (e) {
    log('error', `${label} failed: ${e.message}`);
    toast(`${label} failed: ${e.message}`);
    if (e.code === 'NETWORK') showConnectionError();
  } finally {
    state.busy = false;
    document.querySelectorAll('button').forEach((b) => { b.disabled = false; });
  }
}

async function advance() {
  state.idx++;
  await showCard();
}

function showAnswer() {
  if (!state.info || state.answerShown) return;
  return run('Show answer', async () => {
    state.answerShown = true;
    await renderHtml(state.info.answer);
    updateUI();
  });
}

function rate(ease) {
  if (!state.info || !state.answerShown) return;
  return run('Answer card', async () => {
    const id = state.info.cardId;
    const result = await invoke('answerCards', { answers: [{ cardId: id, ease }] });
    if (!result || result[0] !== true) throw new Error('Anki refused the answer (is the card still due?)');
    state.stats.reviewed++;
    await advance();
  });
}

function skip() {
  if (!state.info) return;
  return run('Skip', async () => { state.stats.skipped++; await advance(); });
}

function suspend() {
  if (!state.info) return;
  return run('Suspend', async () => {
    const id = state.info.cardId;
    const ok = await invoke('suspend', { cards: [id] });
    if (!ok) throw new Error('Anki did not suspend the card');
    state.lastSuspended = id;
    state.stats.suspended++;
    toast('Card suspended');
    await advance();
  });
}

function undoSuspend() {
  if (state.lastSuspended == null) return;
  return run('Undo suspend', async () => {
    const id = state.lastSuspended;
    await invoke('unsuspend', { cards: [id] });
    state.lastSuspended = null;
    state.stats.suspended = Math.max(0, state.stats.suspended - 1);
    state.queue.splice(state.idx, 0, id);
    toast('Card unsuspended');
    await showCard();
  });
}

function deleteNote() {
  if (!state.info) return;
  const info = state.info;
  const ok = window.confirm(
    `Permanently delete this note and ALL of its cards?\n\n"${firstFieldText(info)}"\n\nThis cannot be undone from here.`
  );
  if (!ok) { log('info', 'Delete cancelled by user'); return; }
  return run('Delete', async () => {
    await invoke('deleteNotes', { notes: [info.note] });
    state.stats.deleted++;
    toast('Note deleted');
    await advance();
  });
}

/* ------------------------------------------------------------------ session */

function showConnectionError() {
  const p = $('errorPanel');
  const origin = `chrome-extension://${chrome.runtime.id}`;
  p.innerHTML = '';
  const h = document.createElement('strong');
  h.textContent = 'Cannot reach Anki.';
  p.append(h);
  const ul = document.createElement('ul');
  const items = [
    'Make sure Anki Desktop is open.',
    'Install the AnkiConnect add-on (Tools → Add-ons → Get Add-ons → code 2055492159) and restart Anki.',
    'If it is installed and still failing, open Tools → Add-ons → AnkiConnect → Config and add this extension to "webCorsOriginList", then restart Anki:',
  ];
  for (const t of items) { const li = document.createElement('li'); li.textContent = t; ul.append(li); }
  const code = document.createElement('code');
  code.textContent = `"${origin}"`;
  ul.lastChild.append(document.createElement('br'), code);
  p.append(ul);
  p.hidden = false;
  setStatus('Not connected', 'bad');
}

function setStatus(text, cls = '') {
  const s = $('status');
  s.textContent = text;
  s.className = `status ${cls}`;
}

async function loadDecks(selected) {
  const decks = await invoke('deckNames');
  decks.sort((a, b) => a.localeCompare(b));
  const sel = $('deckSelect');
  sel.innerHTML = '';
  const all = new Option('All decks', '');
  sel.add(all);
  for (const d of decks) sel.add(new Option(d, d));
  sel.value = decks.includes(selected) ? selected : '';
}

async function startSession() {
  const deck = $('deckSelect').value;
  const newLimit = Math.max(0, parseInt($('newLimit').value, 10) || 0);
  await chrome.storage.local.set({ deck, newLimit });

  const scope = deck ? `deck:"${escapeSearch(deck)}" ` : '';
  const due = await invoke('findCards', { query: `${scope}is:due -is:suspended -is:buried` });
  let fresh = [];
  if (newLimit > 0) {
    fresh = (await invoke('findCards', { query: `${scope}is:new -is:suspended -is:buried` })).slice(0, newLimit);
  }
  state.queue = [...due, ...fresh];
  if ($('randomToggle').checked) {
    // Fisher-Yates shuffle
    for (let i = state.queue.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [state.queue[i], state.queue[j]] = [state.queue[j], state.queue[i]];
    }
    log('info', 'Queue shuffled');
  }
  state.idx = 0;
  state.lastSuspended = null;
  state.stats = { reviewed: 0, suspended: 0, deleted: 0, skipped: 0 };
  log('info', `Session: ${due.length} due + ${fresh.length} new`);
  setStatus(`Connected · ${due.length} due, ${fresh.length} new queued`, 'ok');
  await showCard();
}

async function connect() {
  const saved = await chrome.storage.local.get({ deck: '', newLimit: 0 });
  $('newLimit').value = saved.newLimit;
  $('errorPanel').hidden = true;
  setStatus('Connecting…');
  await run('Connect', async () => {
    const version = await invoke('version');
    log('info', `AnkiConnect API version ${version}`);
    await loadDecks(saved.deck);
    await startSession();
  });
}

/* --------------------------------------------------------------------- init */

async function init() {
  const s = await chrome.storage.local.get({ debug: false, random: false, alwaysNewTab: false, reviewOnNewTab: false });
  state.debug = s.debug;
  $('onNewTabToggle').checked = s.reviewOnNewTab;
  $('onNewTabToggle').addEventListener('change', async (e) => {
    await chrome.storage.local.set({ reviewOnNewTab: e.target.checked });
    toast(e.target.checked ? 'Every new tab will open the review page' : 'New tabs go back to the normal New Tab page');
  });
  $('debugToggle').checked = s.debug;
  $('randomToggle').checked = s.random;
  $('newTabToggle').checked = s.alwaysNewTab;
  $('randomToggle').addEventListener('change', async (e) => {
    await chrome.storage.local.set({ random: e.target.checked });
    toast(e.target.checked ? 'Random order on — applies on next Start / reload' : 'Random order off — applies on next Start / reload');
  });
  $('newTabToggle').addEventListener('change', async (e) => {
    await chrome.storage.local.set({ alwaysNewTab: e.target.checked });
    toast(e.target.checked ? 'Icon will always open a new tab' : 'Icon will focus the existing tab');
  });
  applyDebug();
  log('info', `Extension origin: chrome-extension://${chrome.runtime.id}`);

  $('debugToggle').addEventListener('change', async (e) => {
    state.debug = e.target.checked;
    await chrome.storage.local.set({ debug: state.debug });
    applyDebug();
    log('info', `Debug ${state.debug ? 'enabled' : 'disabled'}`);
  });
  $('clearLogBtn').addEventListener('click', () => { logBuffer.length = 0; renderLog(); });
  $('copyLogBtn').addEventListener('click', async () => {
    await navigator.clipboard.writeText($('logOutput').textContent);
    toast('Log copied');
  });

  $('startBtn').addEventListener('click', () => run('Start', startSession).then(() => {}));
  $('restartBtn').addEventListener('click', () => run('Start', startSession));
  $('showBtn').addEventListener('click', showAnswer);
  document.querySelectorAll('.rate').forEach((b) =>
    b.addEventListener('click', () => rate(Number(b.dataset.ease))));
  $('skipBtn').addEventListener('click', skip);
  $('suspendBtn').addEventListener('click', suspend);
  $('undoSuspendBtn').addEventListener('click', undoSuspend);
  $('deleteBtn').addEventListener('click', deleteNote);

  document.addEventListener('keydown', (e) => {
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    const tag = (e.target.tagName || '').toLowerCase();
    if (tag === 'input' || tag === 'select' || tag === 'textarea') return;
    if (state.busy || !state.info) return;
    const k = e.key.toLowerCase();
    if (k === ' ' || k === 'enter') {
      e.preventDefault();
      if (state.answerShown) rate(3); else showAnswer();
    } else if (['1', '2', '3', '4'].includes(k)) rate(Number(k));
    else if (k === 's') suspend();
    else if (k === 'd') deleteNote();
    else if (k === 'k') skip();
    else if (k === 'u') undoSuspend();
  });

  await connect();
}

init();
