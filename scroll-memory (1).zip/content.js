(() => {
  if (window.top !== window) return;
  const TAG = 'infinite-pager';
  const DEFAULTS = { autoRestore: true, pagination: false, strict: false };
  const KEY = location.origin + location.pathname + location.search;
  const MIN_Y = 600;

  let S = { ...DEFAULTS };
  let restoring = false, cancelled = false;
  let pages = [], curPage = 1, lastNet = 0, heldCount = 0, lastTagH = 0, deepLink = 0;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const norm = (s) => (s || '').replace(/\s+/g, ' ').trim().slice(0, 80);
  const pagActive = () => S.pagination || deepLink > 0;

  // ================= debug log (ring buffer) =================
  const LOG = []; const T0 = Date.now();
  let netCount = 0, netRecent = [], lastSaveLog = 0, lastHow = null;
  const log = (ev, data) => {
    const j = JSON.stringify(data === undefined ? null : data);
    const last = LOG[LOG.length - 1];
    if (last && last.ev === ev && last.j === j) { last.n = (last.n || 1) + 1; return; }
    LOG.push({ t: Date.now() - T0, ev, data, j });
    if (LOG.length > 300) LOG.shift();
  };

  // ================= UI (shadow DOM) =================
  const host = document.createElement('div');
  host.id = '__ext-pager-host';
  const root = host.attachShadow({ mode: 'closed' });
  root.innerHTML = `
  <style>
    :host{all:initial}
    *{box-sizing:border-box;font-family:system-ui,-apple-system,Segoe UI,sans-serif}
    [hidden]{display:none!important}
    button{font:inherit;font-size:13px;cursor:pointer;border:0;border-radius:8px;padding:6px 12px;background:#7c6cff;color:#fff}
    button.ghost{background:transparent;color:inherit;border:1px solid #888}
    #curtain{position:fixed;inset:0;z-index:2147483647;background:#0f1115;color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px}
    #bar{width:260px;height:6px;background:#2a2d36;border-radius:3px;overflow:hidden}
    #fill{height:100%;width:3%;background:#7c6cff;transition:width .3s}
    #msg{font-size:16px} #sub{font-size:12px;opacity:.6}
    #banner{position:fixed;top:14px;left:50%;transform:translateX(-50%);z-index:2147483646;background:#fff;color:#111;border-radius:12px;padding:12px 14px;display:flex;gap:10px;align-items:center;box-shadow:0 6px 24px rgba(0,0,0,.25);font-size:14px}
    #nav{position:fixed;bottom:16px;left:50%;transform:translateX(-50%);z-index:2147483646;background:#1b1d24;color:#fff;border-radius:999px;padding:6px 8px;display:flex;gap:8px;align-items:center;box-shadow:0 6px 24px rgba(0,0,0,.35);font-size:13px}
    #nav button{border-radius:999px;padding:4px 10px}
    #toast{position:fixed;bottom:70px;left:50%;transform:translateX(-50%);z-index:2147483646;background:#111;color:#fff;padding:8px 14px;border-radius:8px;font-size:13px}
  </style>
  <div id="curtain" hidden>
    <div id="msg">Fast-forwarding to your spot…</div>
    <div id="bar"><div id="fill"></div></div>
    <div id="sub"></div>
    <button class="ghost" id="cancel" style="color:#fff">Cancel</button>
  </div>
  <div id="banner" hidden>
    <span id="btxt">Resume where you left off?</span>
    <button id="bresume">Resume</button>
    <button id="bpin" hidden>Jump to pin</button>
    <button class="ghost" id="bclose">✕</button>
  </div>
  <div id="nav" hidden>
    <button id="prev">‹</button><span id="pg">Page 1</span><button id="next">›</button>
    <button id="more" hidden>Load next ▸</button>
  </div>
  <div id="toast" hidden></div>`;
  const $ = (id) => root.getElementById(id);

  let toastT;
  const toast = (t) => { const el = $('toast'); el.textContent = t; el.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => (el.hidden = true), 2400); };

  // ================= position capture / lookup =================
  function cssPath(el) {
    const parts = [];
    for (let n = el; n && n !== document.body && parts.length < 30; n = n.parentElement) {
      let i = 1;
      for (let s = n.previousElementSibling; s; s = s.previousElementSibling) if (s.tagName === n.tagName) i++;
      parts.unshift(`${n.tagName.toLowerCase()}:nth-of-type(${i})`);
    }
    return 'body > ' + parts.join(' > ');
  }

  function capture() {
    const y = Math.min(100, innerHeight / 4);
    let el = document.elementsFromPoint(innerWidth / 2, y).find(
      (e) => e !== host && e !== document.documentElement && e !== document.body &&
             !/^(fixed|sticky)$/.test(getComputedStyle(e).position));
    if (!el) return null;
    // climb to "feed item" size
    for (let p = el.parentElement; p && p !== document.body && p !== document.documentElement; p = p.parentElement) {
      const h = p.getBoundingClientRect().height;
      if (h === 0 || h > innerHeight * 0.9) break;
      el = p;
    }
    const link = el.matches('a[href]') ? el : el.querySelector('a[href]');
    let depth = 0;
    for (let n = link; n && n !== el; n = n.parentElement) depth++;
    const img = el.querySelector('img[src]');
    return {
      tag: el.tagName, id: el.id || null, text: norm(el.textContent),
      href: link ? link.getAttribute('href') : null, depth,
      img: img ? img.src : null, path: cssPath(el),
      top: Math.round(el.getBoundingClientRect().top), scrollY: Math.round(scrollY),
      docH: document.documentElement.scrollHeight, ts: Date.now(),
    };
  }

  function sameSig(el, t) {
    if (t.text) return norm(el.textContent).slice(0, 40) === t.text.slice(0, 40);
    if (t.img) return [...el.querySelectorAll('img')].some((i) => i.src === t.img);
    return true;
  }

  function findAnchor(t) {
    lastHow = null;
    try {
      if (t.id) { const e = document.getElementById(t.id); if (e && sameSig(e, t)) { lastHow = 'id'; return e; } }
      if (t.href) {
        for (const a of document.querySelectorAll('a[href]')) {
          if (a.getAttribute('href') !== t.href) continue;
          let e = a;
          for (let i = 0; i < t.depth && e; i++) e = e.parentElement;
          if (e && e.tagName === t.tag && sameSig(e, t)) { lastHow = 'href'; return e; }
        }
      }
      const e = document.querySelector(t.path);
      if (e && sameSig(e, t)) { lastHow = 'css-path'; return e; }
      if (t.text) for (const n of document.body.getElementsByTagName(t.tag)) if (norm(n.textContent) === t.text) { lastHow = 'text'; return n; }
    } catch (err) { log('findAnchor-error', String(err)); }
    return null;
  }

  // ================= seek: keep loading until test() passes =================
  function pushCfg(release) {
    window.postMessage({ __ext: TAG + '-cfg', cfg: { hold: S.strict && pagActive() && !restoring }, release: !!release }, '*');
  }

  async function seek(test, label, expectedH) {
    restoring = true; cancelled = false; pushCfg();
    const t0 = Date.now(); let lastH = 0, stall = 0, res = null, shown = false, iter = 0, reason = 'found';
    log('seek-start', { label, expectedH });
    while (!cancelled && Date.now() - t0 < 30000) {
      res = test();
      if (res) break;
      if (!shown) { shown = true; $('msg').textContent = label; $('curtain').hidden = false; }
      scrollTo(0, document.documentElement.scrollHeight);
      dispatchEvent(new Event('scroll'));
      await sleep(500);
      const h = document.documentElement.scrollHeight;
      stall = h === lastH ? stall + 1 : 0; lastH = h;
      if (++iter % 4 === 0) log('seek-tick', { h, stall, screens: Math.round(h / innerHeight) });
      const pct = expectedH ? Math.min(97, Math.round((h / expectedH) * 100)) : Math.min(90, Math.round((Date.now() - t0) / 300));
      $('fill').style.width = pct + '%';
      $('sub').textContent = `${Math.round(h / innerHeight)} screens loaded`;
      if (stall >= 8) { reason = 'stalled: page height stopped growing'; break; }
    }
    log('seek-end', { found: !!res, how: res ? lastHow : null, reason: res ? 'found' : (cancelled ? 'cancelled' : (reason !== 'found' ? reason : 'timeout 30s')), ms: Date.now() - t0 });
    $('curtain').hidden = true; restoring = false; pushCfg();
    return res;
  }

  async function restoreTo(t) {
    $('banner').hidden = true;
    const el = await seek(() => findAnchor(t), 'Fast-forwarding to your spot…', t.docH);
    if (!el) {
      log('restore-fallback-pixel', { scrollY: t.scrollY });
      scrollTo(0, t.scrollY);
      if (!cancelled) toast('Exact spot not found — approximate position used');
      return;
    }
    const place = () => { el.scrollIntoView({ block: 'start' }); scrollBy(0, -t.top); };
    place();
    log('restore-placed', { how: lastHow, savedTop: t.top, nowTop: Math.round(el.getBoundingClientRect().top) });
    for (const d of [700, 1500]) { // correct for late layout shifts (images etc.)
      await sleep(d === 700 ? 700 : 800);
      if (!el.isConnected) break;
      const diff = el.getBoundingClientRect().top - t.top;
      if (Math.abs(diff) > 4 && Math.abs(diff) < innerHeight * 3) scrollBy(0, diff);
    }
  }

  // ================= storage =================
  async function patchRecord(patch) {
    try {
      const { positions = {} } = await chrome.storage.local.get('positions');
      positions[KEY] = { ...(positions[KEY] || {}), ...patch };
      const keys = Object.keys(positions);
      if (keys.length > 300) {
        keys.sort((a, b) => stamp(positions[a]) - stamp(positions[b]));
        keys.slice(0, keys.length - 300).forEach((k) => delete positions[k]);
      }
      await chrome.storage.local.set({ positions });
    } catch (e) { log('storage-error', String(e)); }
  }
  const stamp = (r) => Math.max(r.auto?.ts || 0, r.pin?.ts || 0);

  let saveT;
  function onScroll() {
    if (restoring) return;
    clearTimeout(saveT);
    saveT = setTimeout(async () => {
      if (restoring || scrollY < MIN_Y) return;
      const p = capture();
      if (p) {
        patchRecord({ auto: p });
        if (Date.now() - lastSaveLog > 3000) { lastSaveLog = Date.now(); log('save', { scrollY: p.scrollY, tag: p.tag, id: p.id, href: p.href, text: p.text.slice(0, 40) }); }
      }
    }, 600);
    updatePage();
  }
  addEventListener('scroll', onScroll, { passive: true });

  async function dropPin() {
    const p = capture();
    if (!p) return toast('Nothing to pin here');
    await patchRecord({ pin: p });
    log('pin', { scrollY: p.scrollY, tag: p.tag, text: p.text.slice(0, 40) });
    toast('📌 Pinned — "read until here"');
  }
  async function jumpPin() {
    const { positions = {} } = await chrome.storage.local.get('positions');
    const pin = positions[KEY]?.pin;
    pin ? restoreTo(pin) : toast('No pin on this page');
  }

  // ================= pagination layer =================
  function renderNav() {
    $('nav').hidden = !pagActive();
    $('pg').textContent = `Page ${curPage} / ${pages.length + 1}`;
    $('more').hidden = !S.strict;
    $('more').textContent = heldCount ? 'Load next ▸ (waiting)' : 'Load next ▸';
  }
  function goPage(n) {
    if (n <= 1) return scrollTo({ top: 0, behavior: 'smooth' });
    pages[n - 2]?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  function updatePage() {
    if (!pagActive() || restoring) return;
    let c = 1;
    pages.forEach((p, i) => { if (p.isConnected && p.getBoundingClientRect().top <= innerHeight * 0.35) c = i + 2; });
    if (c === curPage) return;
    curPage = c; renderNav();
    const h = c > 1 ? '#ext-page-' + c : '';
    if ((location.hash === '' || /^#ext-page-/.test(location.hash)) && location.hash !== h)
      history.replaceState(history.state, '', location.pathname + location.search + h);
  }

  let pending = [], flushT;
  const mo = new MutationObserver((muts) => {
    if (!pagActive()) return;
    for (const m of muts) for (const n of m.addedNodes) {
      if (n.nodeType === 1 && n !== host && !/^(SCRIPT|STYLE|LINK|META|NOSCRIPT)$/.test(n.tagName)) pending.push(n);
    }
    if (pending.length) { clearTimeout(flushT); flushT = setTimeout(flush, 450); }
  });
  function flush() {
    const nodes = pending.filter((n) => n.isConnected && n.getBoundingClientRect().height > 40);
    pending = [];
    const h = document.documentElement.scrollHeight;
    if (!nodes.length) return;
    if (Date.now() - lastNet > 5000) { log('page-skip', { reason: 'no recent network call' }); return; }
    if (h - lastTagH < innerHeight * 0.6) { log('page-skip', { reason: 'height grew too little' }); return; }
    nodes.sort((a, b) => (a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1));
    const first = nodes[0];
    if (first.hasAttribute('data-ext-page')) return;
    first.setAttribute('data-ext-page', pages.length + 2);
    pages.push(first); lastTagH = h; renderNav();
    log('page-tag', { page: pages.length + 1, tag: first.tagName, id: first.id || null, cls: String(first.className).slice(0, 60), heightNow: h });
  }

  // ================= events =================
  addEventListener('message', (e) => {
    const d = e.data;
    if (e.source !== window || !d || d.__ext !== TAG) return;
    if (d.type === 'net') { lastNet = Date.now(); netCount++; netRecent.push(String(d.url || '').slice(0, 140)); if (netRecent.length > 8) netRecent.shift(); }
    if (d.type === 'held') { heldCount = d.n; log('held', { n: d.n }); renderNav(); }
  });

  $('cancel').onclick = () => { cancelled = true; };
  $('bclose').onclick = () => ($('banner').hidden = true);
  $('prev').onclick = () => goPage(curPage - 1);
  $('next').onclick = () => {
    if (pages.length + 1 > curPage) goPage(curPage + 1);
    else { pushCfg(true); scrollTo({ top: document.documentElement.scrollHeight, behavior: 'smooth' }); }
  };
  $('more').onclick = () => { pushCfg(true); toast('Loading next page…'); };

  async function buildReport() {
    let rec = null;
    try { const { positions = {} } = await chrome.storage.local.get('positions'); rec = positions[KEY] || null; }
    catch (e) { rec = 'ERR ' + e.message; }
    let cur; try { cur = capture(); } catch (e) { cur = 'ERR ' + e.message; }
    let saved = null;
    if (rec && rec.auto) { const el = findAnchor(rec.auto); saved = el ? { found: true, how: lastHow, tag: el.tagName, top: Math.round(el.getBoundingClientRect().top) } : { found: false }; }
    // inner scrollers: sites that scroll a <div> instead of the window
    const scrollers = [];
    try {
      for (const e of document.querySelectorAll('div,main,section,ul,ol')) {
        if (scrollers.length >= 5) break;
        if (e.scrollHeight > e.clientHeight * 1.5 && e.clientHeight > 150 && /(auto|scroll)/.test(getComputedStyle(e).overflowY))
          scrollers.push({ el: e.tagName.toLowerCase() + (e.id ? '#' + e.id : '') + (e.className && typeof e.className === 'string' ? '.' + e.className.trim().split(/\s+/).slice(0, 2).join('.') : ''), scrollHeight: e.scrollHeight, clientHeight: e.clientHeight });
      }
    } catch (_) {}
    const de = document.documentElement;
    return JSON.stringify({
      extension: 'Scroll Memory & Pager v' + chrome.runtime.getManifest().version,
      generatedAt: new Date().toISOString(),
      userAgent: navigator.userAgent,
      url: location.href, storageKey: KEY,
      settings: S, deepLink,
      state: { restoring, readyState: document.readyState, scrollY: Math.round(scrollY), innerHeight, scrollHeight: de.scrollHeight, windowScrollsMainContent: de.scrollHeight > innerHeight * 1.05 },
      innerScrollers: scrollers,
      pagination: { pagesTagged: pages.length, currentPage: curPage, heldRequests: heldCount, networkEventsSeen: netCount, recentNetwork: netRecent },
      savedRecord: rec, savedAnchorLookupNow: saved, currentCapture: cur,
      log: LOG.map(({ t, ev, data, n }) => ({ t_ms: t, ev, data, ...(n > 1 ? { repeated: n } : {}) })),
    }, null, 2);
  }

  chrome.runtime.onMessage.addListener((m, _sender, send) => {
    if (m.type === 'pin') dropPin();
    if (m.type === 'jump-pin') jumpPin();
    if (m.type === 'get-debug') { buildReport().then(send, (e) => send('REPORT ERROR: ' + e.message)); return true; }
    if (m.type === 'clear-debug') { LOG.length = 0; netCount = 0; netRecent = []; send('ok'); }
  });
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'sync') return;
    for (const k in ch) S[k] = ch[k].newValue;
    pushCfg(); renderNav();
  });

  // ================= init =================
  async function init() {
    document.documentElement.appendChild(host);
    const [s, { positions = {} }] = await Promise.all([
      chrome.storage.sync.get(DEFAULTS), chrome.storage.local.get('positions')]);
    S = { ...DEFAULTS, ...s };
    const m = location.hash.match(/^#ext-page-(\d+)$/);
    deepLink = m ? +m[1] : 0;
    log('init', { key: KEY, S, deepLink, hasSaved: !!positions[KEY]?.auto, hasPin: !!positions[KEY]?.pin });
    lastTagH = document.documentElement.scrollHeight;
    mo.observe(document.documentElement, { childList: true, subtree: true });
    pushCfg(); renderNav();
    await sleep(900); // let the site render its first batch

    if (deepLink > 1) {
      const ok = await seek(() => pages.length >= deepLink - 1, `Loading page ${deepLink}…`);
      ok ? goPage(deepLink) : toast('Could not reach that page');
      return;
    }
    const rec = positions[KEY] || {};
    if (rec.auto && rec.auto.scrollY > MIN_Y) {
      log('restore-mode', { auto: S.autoRestore, savedY: rec.auto.scrollY });
      if (S.autoRestore) return restoreTo(rec.auto);
      $('btxt').textContent = 'Resume where you left off?';
      $('bresume').onclick = () => restoreTo(rec.auto);
      if (rec.pin) { $('bpin').hidden = false; $('bpin').onclick = () => restoreTo(rec.pin); }
      $('banner').hidden = false;
      setTimeout(() => ($('banner').hidden = true), 15000);
    }
  }
  document.readyState === 'loading' ? addEventListener('DOMContentLoaded', init) : init();
})();
