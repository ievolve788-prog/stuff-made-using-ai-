const D = { autoRestore: true, pagination: false, strict: false };
const ids = Object.keys(D);
chrome.storage.sync.get(D).then((s) => {
  ids.forEach((id) => {
    const el = document.getElementById(id);
    el.checked = s[id];
    el.onchange = () => chrome.storage.sync.set({ [id]: el.checked });
  });
});
document.getElementById('clear').onclick = async (e) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const u = new URL(tab.url);
  const key = u.origin + u.pathname + u.search;
  const { positions = {} } = await chrome.storage.local.get('positions');
  delete positions[key];
  await chrome.storage.local.set({ positions });
  e.target.textContent = 'Cleared ✓';
};

// ---- debug ----
const stat = (t) => (document.getElementById('dstat').textContent = t);
async function activeTab() { return (await chrome.tabs.query({ active: true, currentWindow: true }))[0]; }
document.getElementById('copy').onclick = async () => {
  try {
    const tab = await activeTab();
    const report = await chrome.tabs.sendMessage(tab.id, { type: 'get-debug' });
    const box = document.getElementById('dout');
    box.value = report; box.hidden = false;
    try { await navigator.clipboard.writeText(report); stat('Copied ✓ (' + report.length + ' chars) — paste it in chat'); }
    catch (_) { box.select(); document.execCommand('copy'); stat('Copied via fallback ✓ — or select the box and copy'); }
  } catch (e) {
    stat('No data: reload this tab once (extension not active here, e.g. chrome:// pages).');
  }
};
document.getElementById('clearlog').onclick = async () => {
  try { await chrome.tabs.sendMessage((await activeTab()).id, { type: 'clear-debug' }); stat('Log cleared'); }
  catch (_) { stat('Reload the tab first'); }
};
