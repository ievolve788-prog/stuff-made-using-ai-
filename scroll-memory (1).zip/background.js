chrome.commands.onCommand.addListener(async (cmd) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  chrome.tabs.sendMessage(tab.id, { type: cmd === 'drop-pin' ? 'pin' : 'jump-pin' }).catch(() => {});
});
