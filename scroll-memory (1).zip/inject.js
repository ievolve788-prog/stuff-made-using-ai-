(() => {
  const TAG = 'infinite-pager';
  const t0 = Date.now();
  const cfg = { hold: false, allowUntil: 0 };
  const queue = [];
  const post = (d) => window.postMessage({ __ext: TAG, ...d }, '*');

  addEventListener('message', (e) => {
    const d = e.data;
    if (e.source !== window || !d || d.__ext !== TAG + '-cfg') return;
    if (d.cfg) Object.assign(cfg, d.cfg);
    if (d.release) {
      cfg.allowUntil = Date.now() + 3000;      // let follow-up requests (cursor, images) through
      while (queue.length) queue.shift()();
      post({ type: 'held', n: 0 });
    }
  });

  const nearBottom = () =>
    scrollY + innerHeight > document.documentElement.scrollHeight - innerHeight * 2;

  const shouldHold = () =>
    cfg.hold && Date.now() > cfg.allowUntil && Date.now() - t0 > 3000 && nearBottom();

  // ---- fetch ----
  const origFetch = window.fetch;
  window.fetch = function (...args) {
    const run = () =>
      origFetch.apply(this, args).then((res) => {
        try { post({ type: 'net', url: res.url, ct: res.headers.get('content-type') || '' }); } catch (_) {}
        return res;
      });
    if (shouldHold()) {
      return new Promise((resolve, reject) => {
        queue.push(() => run().then(resolve, reject));
        post({ type: 'held', n: queue.length });
      });
    }
    return run();
  };

  // ---- XHR (observe only, not held) ----
  const origSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function (...a) {
    this.addEventListener('loadend', () => post({ type: 'net', url: this.responseURL }));
    return origSend.apply(this, a);
  };
})();
