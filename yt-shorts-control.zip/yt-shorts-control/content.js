/* Shorts Control for YouTube - content script */
(() => {
  'use strict';
  if (window.__ytsLoaded) return;
  window.__ytsLoaded = true;

  const { mergeSettings, formatEntry, buildReport, copyText } = window.YTS;
  const NAME = 'Shorts Control';
  const CACHE_KEY = '__yts_cache_v1';
  const FEED_PAGES = ['home', 'search', 'subs'];
  const html = document.documentElement;

  // Elements that represent one video "card" in the various YouTube layouts.
  const ITEM_SEL = [
    'ytd-rich-item-renderer', 'ytd-video-renderer', 'ytd-grid-video-renderer',
    'ytd-compact-video-renderer', 'ytd-reel-item-renderer', 'yt-lockup-view-model',
    'ytm-shorts-lockup-view-model', 'ytm-shorts-lockup-view-model-v2'
  ].join(',');

  // The visible page container for each page type (YouTube keeps old pages in the DOM, hidden).
  const PAGE_ROOT = {
    home: 'ytd-browse[page-subtype="home"]',
    search: 'ytd-search',
    subs: 'ytd-browse[page-subtype="subscriptions"]',
    watch: 'ytd-watch-flexy'
  };

  let settings = mergeSettings(readCache());
  let alive = true;
  let observer = null;
  let host = null, sh = null;
  const els = {};
  const cardCache = new Map();
  let shorts = new Map();
  let lastSig = '', lastMarked = -1, lastUnmatched = 0, lastKey = '', lastHref = location.href;
  let logOpen = false, logTimer = 0, flashTimer = 0;

  /* ------------------------------------------------------------------ logging */
  const buf = [];
  let flushTimer = 0;

  function safe(d) { try { return JSON.parse(JSON.stringify(d)); } catch (_) { return String(d); } }

  function log(lvl, msg, data) {
    if (lvl === 'debug' && !settings.verbose) return;
    const e = { t: Date.now(), lvl, src: 'content', msg };
    if (data !== undefined) e.data = safe(data);
    buf.push(e);
    if (buf.length > 300) buf.splice(0, buf.length - 300);
    if (lvl === 'warn' || lvl === 'error') console[lvl](`[${NAME}]`, msg, data === undefined ? '' : data);
    if (!flushTimer) flushTimer = setTimeout(flush, 700);
  }

  function onCtxError(err) {
    if (/context invalidated/i.test(String((err && err.message) || err))) teardown();
  }

  function flush() {
    flushTimer = 0;
    if (!buf.length || !alive) return;
    const entries = buf.splice(0);
    try {
      chrome.runtime.sendMessage({ type: 'log', entries }).catch(onCtxError);
    } catch (err) { onCtxError(err); }
  }

  function teardown() {
    if (!alive) return;
    alive = false;
    if (observer) observer.disconnect();
    if (host) host.remove();
    clearInterval(logTimer);
    ['data-yts-mode', 'data-yts-page', 'data-yts-guide'].forEach((a) => html.removeAttribute(a));
    console.warn(`[${NAME}] Extension was reloaded - this old page script stopped. Refresh the tab.`);
  }

  window.addEventListener('error', (e) => log('error', 'uncaught error', { message: e.message, file: e.filename, line: e.lineno }));
  window.addEventListener('unhandledrejection', (e) => log('error', 'unhandled rejection', { reason: String(e.reason) }));

  /* ------------------------------------------------------------------ settings */
  function readCache() {
    try { return JSON.parse(localStorage.getItem(CACHE_KEY) || 'null') || {}; } catch (_) { return {}; }
  }
  function writeCache() {
    try { localStorage.setItem(CACHE_KEY, JSON.stringify(settings)); } catch (_) { /* ignore */ }
  }

  /* --------------------------------------------------------------- page state */
  function pageType() {
    const p = location.pathname;
    if (p === '/') return 'home';
    if (p === '/results') return 'search';
    if (p.startsWith('/feed/subscriptions')) return 'subs';
    if (p === '/watch') return 'watch';
    return 'other';
  }

  function effectiveMode() {
    const p = pageType();
    if (p === 'other' || !settings.pages[p]) return 'show';
    if (p === 'watch' && settings.mode === 'column') return 'hide'; // no room for a column next to the player
    return settings.mode;
  }

  function activeRoot() {
    const sel = PAGE_ROOT[pageType()];
    return sel ? document.querySelector(sel + ':not([hidden])') : null;
  }

  function statusInfo() {
    const root = activeRoot();
    return {
      url: location.href,
      page: pageType(),
      mode: effectiveMode(),
      configuredMode: settings.mode,
      shorts: shorts.size,
      markedElements: document.querySelectorAll('[data-yts-short]').length,
      activeRoot: root ? root.localName : null,
      uiMounted: !!(host && host.isConnected)
    };
  }

  function apply(reason) {
    if (!alive) return;
    const page = pageType();
    const mode = effectiveMode();
    html.setAttribute('data-yts-mode', mode);
    html.setAttribute('data-yts-page', page);
    html.setAttribute('data-yts-guide', settings.hideGuide ? 'hide' : 'show');
    html.style.setProperty('--yts-w', settings.columnWidth + 'px');

    ensureUI();
    syncUI();

    const key = [page, mode, settings.columnWidth, settings.hideGuide].join('|');
    if (key !== lastKey) {
      lastKey = key;
      log('info', 'state applied', { reason, page, mode, columnWidth: settings.columnWidth });
      // YouTube lays its grid out from the container width; nudge it to re-measure.
      setTimeout(() => window.dispatchEvent(new Event('resize')), 80);
    }
    scheduleScan(reason);
  }

  /* --------------------------------------------------------------------- scan */
  let scanTimer = 0, lastScan = 0;
  function scheduleScan(reason) {
    if (scanTimer || !alive) return;
    const wait = Math.max(50, 300 - (Date.now() - lastScan));
    scanTimer = setTimeout(() => { scanTimer = 0; lastScan = Date.now(); scan(reason); }, wait);
  }

  const clean = (t) => (t || '').replace(/\s+/g, ' ').replace(/\s*[-\u2013\u2014]\s*play short$/i, '').trim().slice(0, 160);

  function chain(el, n = 7) {
    const out = [];
    for (let i = 0; el && i < n; i++, el = el.parentElement) out.push(el.localName + (el.id ? '#' + el.id : ''));
    return out.join(' < ');
  }

  function pickTitle(scope, a) {
    const q = (s) => (scope.querySelector ? scope.querySelector(s) : null);
    const cands = [
      a.getAttribute('title'),
      (q('#video-title') || {}).textContent,
      (q('.shortsLockupViewModelHostMetadataTitle') || {}).textContent,
      (q('h3') || {}).textContent,
      a.getAttribute('aria-label'),
      a.textContent
    ];
    for (const c of cands) { const s = clean(c); if (s) return s; }
    return '';
  }

  function pickViews(scope) {
    const el = scope.querySelector && scope.querySelector('.shortsLockupViewModelHostMetadataSubhead, #metadata-line span, .inline-metadata-item');
    return clean(el && el.textContent);
  }

  function pickThumb(scope) {
    const img = scope.querySelector && scope.querySelector('img');
    const src = img && img.currentSrc ? img.currentSrc : img && img.src;
    return src && /^https:\/\/i\d*\.ytimg\.com\//.test(src) ? src : '';
  }

  function scan(reason) {
    if (!alive) return;
    const t0 = performance.now();
    try {
      const page = pageType();
      if (page === 'other' || !settings.pages[page]) {
        if (shorts.size) { shorts = new Map(); lastSig = ''; renderPanel(); }
        return;
      }
      let root = activeRoot();
      if (!root) {
        root = document;
        if (reason !== 'mutation') log('warn', 'active page container not found; scanning whole document', { page });
      }

      let newlyMarked = 0;
      const mark = (el) => { if (el && !el.hasAttribute('data-yts-short')) { el.setAttribute('data-yts-short', ''); newlyMarked++; } };

      // 1) Whole Shorts shelves.
      root.querySelectorAll('ytd-reel-shelf-renderer, ytd-rich-shelf-renderer[is-shorts]').forEach((shelf) => {
        mark(shelf);
        mark(shelf.closest('ytd-rich-section-renderer'));
      });

      // 2) Every individual link to /shorts/<id>.
      const found = new Map();
      const unmatched = [];
      root.querySelectorAll('a[href*="/shorts/"]').forEach((a) => {
        const m = /^\/shorts\/([\w-]{5,})/.exec(a.pathname);
        if (!m) return;

        const nearest = a.closest(ITEM_SEL);
        let outer = nearest, up = nearest;
        while (up && (up = up.parentElement && up.parentElement.closest(ITEM_SEL))) outer = up;
        mark(nearest); mark(outer);
        mark(a.closest('grid-shelf-view-model'));
        if (!nearest && !a.closest('[data-yts-short]')) unmatched.push(a);

        const scope = nearest || a.parentElement || a;
        const id = m[1];
        const rec = found.get(id) || { id, title: '', views: '', thumb: '', a };
        rec.title = rec.title || pickTitle(scope, a);
        rec.views = rec.views || pickViews(scope);
        rec.thumb = rec.thumb || pickThumb(scope);
        found.set(id, rec);
      });

      // Keep details we already had if this pass could not read them.
      found.forEach((rec, id) => {
        const prev = shorts.get(id);
        if (prev) { rec.title = rec.title || prev.title; rec.views = rec.views || prev.views; rec.thumb = rec.thumb || prev.thumb; }
      });
      shorts = found;

      const sig = [...found.values()].map((r) => `${r.id}|${r.title}|${r.views}|${r.thumb}`).join('\n');
      const marked = document.querySelectorAll('[data-yts-short]').length;
      if (sig !== lastSig) {
        lastSig = sig;
        renderPanel();
      }
      if (marked !== lastMarked || newlyMarked) {
        log('debug', 'scan', { reason, page, mode: effectiveMode(), shorts: found.size, marked, newlyMarked, ms: Math.round(performance.now() - t0) });
        lastMarked = marked;
      }
      if (unmatched.length !== lastUnmatched) {
        if (unmatched.length) {
          log('warn', 'Short links outside any known container (these stay visible)', {
            count: unmatched.length,
            samples: unmatched.slice(0, 3).map((a) => ({ href: a.getAttribute('href'), chain: chain(a) }))
          });
        }
        lastUnmatched = unmatched.length;
      }
    } catch (err) {
      log('error', 'scan failed', { message: String(err && err.message), stack: String(err && err.stack).split('\n').slice(0, 3) });
    }
  }

  function diagnose() {
    const counts = {};
    [
      'ytd-browse', 'ytd-search', 'ytd-watch-flexy', 'ytd-rich-grid-renderer', 'ytd-rich-item-renderer',
      'ytd-rich-shelf-renderer[is-shorts]', 'ytd-reel-shelf-renderer', 'ytd-video-renderer',
      'ytd-compact-video-renderer', 'yt-lockup-view-model', 'grid-shelf-view-model',
      'ytm-shorts-lockup-view-model', 'ytm-shorts-lockup-view-model-v2', 'a[href*="/shorts/"]', '[data-yts-short]'
    ].forEach((s) => { counts[s] = document.querySelectorAll(s).length; });
    log('info', 'DIAGNOSTICS', Object.assign(statusInfo(), { counts }));

    const links = [...document.querySelectorAll('a[href*="/shorts/"]')];
    log('info', 'DIAGNOSTICS short-link samples', links.slice(0, 5).map((a) => ({
      href: a.getAttribute('href'), chain: chain(a), covered: !!a.closest('[data-yts-short]')
    })));
    const open = links.filter((a) => !a.closest('[data-yts-short]')).slice(0, 5);
    if (open.length) log('warn', 'Short links NOT covered by a hidden container', open.map((a) => ({ href: a.getAttribute('href'), chain: chain(a) })));
    scan('diagnose');
  }

  /* ----------------------------------------------------------------------- UI */
  const SHADOW_CSS = `
:host{all:initial;display:block;--bg:#fff;--fg:#0f0f0f;--mut:#606060;--bd:rgba(0,0,0,.14);--hov:rgba(0,0,0,.07);--sh:0 4px 18px rgba(0,0,0,.2);--w:300px;font:400 13px/1.35 Roboto,Arial,sans-serif;color:var(--fg)}
:host-context(html[dark]){--bg:#212121;--fg:#f1f1f1;--mut:#aaa;--bd:rgba(255,255,255,.18);--hov:rgba(255,255,255,.12);--sh:0 4px 18px rgba(0,0,0,.65)}
[hidden]{display:none!important}
*{box-sizing:border-box}
button{font:inherit;color:inherit;background:none;border:0;cursor:pointer}
button:focus-visible,a:focus-visible{outline:2px solid #3ea6ff;outline-offset:1px}
.wrap{position:fixed;top:64px;right:16px;z-index:2200;display:flex;flex-direction:column;align-items:flex-end;gap:8px;max-height:calc(100vh - 76px);pointer-events:none}
.wrap>*{pointer-events:auto}
.bar,.panel,.logbox,.mini{background:var(--bg);border:1px solid var(--bd);box-shadow:var(--sh)}
.bar{flex:none;display:flex;align-items:center;gap:6px;padding:4px 6px 4px 12px;border-radius:999px}
.label{font-weight:500;white-space:nowrap}
.count{display:inline-block;min-width:22px;padding:0 6px;margin-left:4px;border-radius:999px;background:var(--hov);text-align:center;font-size:12px}
.seg{display:flex;background:var(--hov);border-radius:999px;padding:2px}
.seg button{padding:5px 12px;border-radius:999px;font-weight:500}
.seg button.on{background:var(--fg);color:var(--bg)}
.ico{width:28px;height:28px;border-radius:50%;font-size:14px;line-height:1}
.ico:hover{background:var(--hov)}
.mini{flex:none;width:36px;height:36px;border-radius:50%;font-weight:700;font-size:15px;color:#fff;background:#c00;border-color:#c00}
.panel{width:var(--w);flex:1 1 auto;min-height:0;display:flex;flex-direction:column;border-radius:14px;overflow:hidden}
.ph{flex:none;padding:10px 14px;font-weight:500;border-bottom:1px solid var(--bd)}
.list{flex:1 1 auto;min-height:0;overflow-y:auto;padding:6px;scrollbar-width:thin}
.card{display:flex;gap:10px;padding:6px;border-radius:10px;text-decoration:none;color:inherit}
.card:hover{background:var(--hov)}
.thumb{flex:none;width:84px;aspect-ratio:9/16;object-fit:cover;border-radius:8px;background:var(--hov)}
.txt{min-width:0;padding-top:2px}
.t{font-weight:500;display:-webkit-box;-webkit-line-clamp:4;-webkit-box-orient:vertical;overflow:hidden;word-break:break-word}
.v{margin-top:4px;color:var(--mut);font-size:12px}
.empty{padding:18px 12px;color:var(--mut);text-align:center}
.logbox{flex:none;width:min(580px,calc(100vw - 32px));border-radius:12px;display:flex;flex-direction:column;overflow:hidden}
.logtools{display:flex;gap:6px;align-items:center;padding:8px;border-bottom:1px solid var(--bd);flex-wrap:wrap}
.logtools button{padding:5px 11px;border:1px solid var(--bd);border-radius:999px;font-weight:500}
.logtools button:hover{background:var(--hov)}
.logtools .primary{background:var(--fg);color:var(--bg);border-color:var(--fg)}
.msg{margin-left:auto;color:var(--mut);font-size:12px}
pre{margin:0;padding:8px 10px;max-height:34vh;overflow:auto;font:11px/1.45 ui-monospace,Consolas,Menlo,monospace;white-space:pre-wrap;word-break:break-all;user-select:text;cursor:text}
`;

  function ensureUI() {
    if (host && host.isConnected) return;
    if (!document.body) return;
    host = document.createElement('div');
    host.id = 'yts-root';
    sh = host.attachShadow({ mode: 'open' });
    sh.innerHTML = `<style>${SHADOW_CSS}</style>
<div class="wrap">
  <div class="bar" hidden>
    <span class="label">Shorts<span class="count">0</span></span>
    <div class="seg" role="group" aria-label="Shorts mode">
      <button data-mode="show" title="Show Shorts where YouTube puts them">Show</button>
      <button data-mode="hide" title="Hide all Shorts">Hide</button>
      <button data-mode="column" title="Move Shorts to a column on the right">Column</button>
    </div>
    <button class="ico" data-act="log" title="Debug log" aria-label="Debug log">&#128030;</button>
    <button class="ico" data-act="collapse" title="Minimise" aria-label="Minimise">&#8211;</button>
  </div>
  <button class="mini" data-act="expand" title="Shorts Control" aria-label="Open Shorts Control" hidden>S</button>
  <div class="logbox" hidden>
    <div class="logtools">
      <button class="primary" data-act="copy">Copy log</button>
      <button data-act="diag">Run diagnostics</button>
      <button data-act="clear">Clear</button>
      <span class="msg"></span>
    </div>
    <pre class="logtext"></pre>
  </div>
  <div class="panel" hidden>
    <div class="ph">Shorts <span class="n">0</span></div>
    <div class="list"></div>
  </div>
</div>`;
    els.bar = sh.querySelector('.bar');
    els.mini = sh.querySelector('.mini');
    els.logbox = sh.querySelector('.logbox');
    els.logtext = sh.querySelector('.logtext');
    els.msg = sh.querySelector('.msg');
    els.panel = sh.querySelector('.panel');
    els.list = sh.querySelector('.list');
    els.count = sh.querySelector('.count');
    els.n = sh.querySelector('.n');
    sh.addEventListener('click', onUIClick);
    document.body.appendChild(host);
    renderPanel();
    log('debug', 'UI mounted');
  }

  function syncUI() {
    if (!host || !sh) return;
    const page = pageType();
    const feed = FEED_PAGES.includes(page);
    const showBar = feed && settings.pages[page] && settings.showWidget;
    const showPanel = feed && effectiveMode() === 'column';
    host.style.display = showBar || showPanel ? 'block' : 'none';
    host.style.setProperty('--w', settings.columnWidth + 'px');
    els.bar.hidden = !showBar || settings.collapsed;
    els.mini.hidden = !showBar || !settings.collapsed;
    els.panel.hidden = !showPanel;
    els.logbox.hidden = !(showBar && logOpen);
    sh.querySelectorAll('.seg button').forEach((b) => {
      const on = b.dataset.mode === settings.mode;
      b.classList.toggle('on', on);
      b.setAttribute('aria-pressed', String(on));
    });
  }

  function makeCard(r) {
    const a = document.createElement('a');
    a.className = 'card';
    a.href = '/shorts/' + r.id;
    a.dataset.id = r.id;
    const img = document.createElement('img');
    img.className = 'thumb';
    img.loading = 'lazy';
    img.alt = '';
    const fallback = `https://i.ytimg.com/vi/${r.id}/hqdefault.jpg`;
    img.onerror = () => { if (img.src !== fallback) img.src = fallback; };
    const box = document.createElement('div');
    box.className = 'txt';
    const t = document.createElement('div'); t.className = 't';
    const v = document.createElement('div'); v.className = 'v';
    box.append(t, v);
    a.append(img, box);
    a._img = img; a._t = t; a._v = v; a._src = '';
    return a;
  }

  function renderPanel() {
    if (!els.list) return;
    els.count.textContent = shorts.size;
    els.n.textContent = shorts.size;
    const scroll = els.list.scrollTop;

    if (!shorts.size) {
      const d = document.createElement('div');
      d.className = 'empty';
      d.textContent = 'No Shorts found on this page yet. Scroll down to load more.';
      els.list.replaceChildren(d);
      return;
    }
    const nodes = [];
    for (const r of shorts.values()) {
      let c = cardCache.get(r.id);
      if (!c) { c = makeCard(r); cardCache.set(r.id, c); }
      const want = r.thumb || `https://i.ytimg.com/vi/${r.id}/hqdefault.jpg`;
      if (c._src !== want) { c._src = want; c._img.src = want; }
      c._t.textContent = r.title || 'Short';
      c._v.textContent = r.views;
      nodes.push(c);
    }
    for (const id of cardCache.keys()) if (!shorts.has(id)) cardCache.delete(id);
    els.list.replaceChildren(...nodes);
    els.list.scrollTop = scroll;
  }

  function setMode(mode) {
    if (settings.mode === mode) return;
    settings = mergeSettings(Object.assign({}, settings, { mode }));
    writeCache();
    apply('widget');
    log('info', 'mode changed from page toggle', { mode });
    chrome.storage.sync.set({ mode }).catch(onCtxError);
  }

  function onCardClick(e, card) {
    if (e.button !== 0 || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
    const rec = shorts.get(card.dataset.id);
    if (!(rec && rec.a && rec.a.isConnected)) { log('debug', 'opening Short by full page load', { id: card.dataset.id }); return; }
    // Click YouTube's own (hidden) link so it navigates without a full reload.
    e.preventDefault();
    const before = location.href;
    rec.a.click();
    setTimeout(() => {
      if (alive && location.href === before) {
        log('warn', 'in-page navigation did not happen; falling back to full load', { id: card.dataset.id });
        location.href = card.href;
      }
    }, 900);
  }

  async function fetchLog() {
    flush();
    try {
      const r = await chrome.runtime.sendMessage({ type: 'getLog' });
      return (r && r.entries) || [];
    } catch (err) { onCtxError(err); return []; }
  }

  async function refreshLogBox() {
    if (!alive || !logOpen) return;
    const entries = await fetchLog();
    const lines = entries.map(formatEntry);
    const shown = lines.slice(-200);
    els.logtext.textContent = (lines.length > 200 ? `... ${lines.length - 200} older lines not shown (Copy log includes everything) ...\n` : '') + shown.join('\n');
    els.logtext.scrollTop = els.logtext.scrollHeight;
  }

  function flash(text) {
    els.msg.textContent = text;
    clearTimeout(flashTimer);
    flashTimer = setTimeout(() => { els.msg.textContent = ''; }, 3000);
  }

  async function copyLog() {
    const entries = await fetchLog();
    const ok = await copyText(buildReport({ entries, settings, context: statusInfo() }));
    flash(ok ? `Copied ${entries.length} entries` : 'Copy failed - select the text and copy manually');
    log('info', 'log copy requested from page', { ok, entries: entries.length });
  }

  function toggleLog() {
    logOpen = !logOpen;
    clearInterval(logTimer);
    if (logOpen) { refreshLogBox(); logTimer = setInterval(refreshLogBox, 2500); }
    syncUI();
  }

  async function onUIClick(e) {
    const card = e.target.closest('a.card');
    if (card) return onCardClick(e, card);
    const btn = e.target.closest('button');
    if (!btn) return;
    if (btn.dataset.mode) return setMode(btn.dataset.mode);
    switch (btn.dataset.act) {
      case 'collapse':
      case 'expand':
        settings = mergeSettings(Object.assign({}, settings, { collapsed: btn.dataset.act === 'collapse' }));
        writeCache(); syncUI();
        chrome.storage.sync.set({ collapsed: settings.collapsed }).catch(onCtxError);
        break;
      case 'log': toggleLog(); break;
      case 'copy': await copyLog(); break;
      case 'diag': diagnose(); await refreshLogBox(); flash('Diagnostics added to log'); break;
      case 'clear':
        buf.length = 0;
        try { await chrome.runtime.sendMessage({ type: 'clearLog' }); } catch (err) { onCtxError(err); }
        await refreshLogBox(); flash('Log cleared');
        break;
    }
  }

  /* --------------------------------------------------------------- navigation */
  function onNav(src) {
    if (location.href === lastHref && src !== 'yt-navigate-finish') return;
    lastHref = location.href;
    log('debug', 'navigation', { src, href: location.href, page: pageType() });
    apply('nav:' + src);
  }

  document.addEventListener('yt-navigate-finish', () => onNav('yt-navigate-finish'));
  document.addEventListener('yt-page-data-updated', () => onNav('yt-page-data-updated'));
  window.addEventListener('popstate', () => onNav('popstate'));

  /* ----------------------------------------------------------------- messages */
  try {
    chrome.runtime.onMessage.addListener((msg, _sender, send) => {
      if (!msg) return;
      if (msg.type === 'status') { send(statusInfo()); }
      else if (msg.type === 'diagnose') { diagnose(); flush(); send({ ok: true }); }
    });

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'sync' || !alive) return;
      const next = Object.assign({}, settings);
      Object.keys(changes).forEach((k) => { next[k] = changes[k].newValue; });
      const merged = mergeSettings(next);
      if (JSON.stringify(merged) === JSON.stringify(settings)) return;
      settings = merged;
      writeCache();
      log('info', 'settings changed', { keys: Object.keys(changes) });
      apply('storage');
    });
  } catch (err) { onCtxError(err); }

  /* --------------------------------------------------------------------- boot */
  log('info', 'content script started', { url: location.href, readyState: document.readyState });
  apply('boot-cache');

  observer = new MutationObserver(() => {
    if (location.href !== lastHref) onNav('observer');
    else scheduleScan('mutation');
  });
  observer.observe(html, { childList: true, subtree: true, attributes: true, attributeFilter: ['href'] });

  chrome.storage.sync.get(null).then((stored) => {
    settings = mergeSettings(stored);
    writeCache();
    log('info', 'settings loaded', settings);
    apply('boot-storage');
  }).catch(onCtxError);

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => apply('dom-ready'), { once: true });
  }
})();
