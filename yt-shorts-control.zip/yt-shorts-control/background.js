/* Service worker: single writer for the shared debug log + keyboard shortcut. */
importScripts('shared.js');

const { MODES, DEFAULTS } = self.YTS;
const MAX_LOG = 1500;

// All reads/writes of the log go through one promise chain so tabs can't clobber each other.
let queue = Promise.resolve();
function enqueue(fn) {
  const p = queue.then(fn);
  queue = p.catch(() => {});
  return p;
}

function append(entries) {
  return enqueue(async () => {
    const { debugLog = [] } = await chrome.storage.local.get('debugLog');
    await chrome.storage.local.set({ debugLog: debugLog.concat(entries).slice(-MAX_LOG) });
  });
}

function bgLog(lvl, msg, data) {
  const e = { t: Date.now(), lvl, src: 'background', msg };
  if (data !== undefined) e.data = data;
  return append([e]);
}

chrome.runtime.onInstalled.addListener((d) => {
  bgLog('info', 'extension installed/updated', {
    reason: d.reason,
    version: chrome.runtime.getManifest().version
  });
});

chrome.commands.onCommand.addListener(async (cmd) => {
  if (cmd !== 'cycle-mode') return;
  const { mode = DEFAULTS.mode } = await chrome.storage.sync.get('mode');
  const next = MODES[(MODES.indexOf(mode) + 1) % MODES.length];
  await chrome.storage.sync.set({ mode: next });
  bgLog('info', 'shortcut: cycle mode', { from: mode, to: next });
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return;

  if (msg.type === 'log' && Array.isArray(msg.entries)) {
    const tab = sender.tab ? sender.tab.id : undefined;
    append(msg.entries.map((e) => (tab != null ? Object.assign({ tab }, e) : e)))
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (msg.type === 'getLog') {
    enqueue(async () => (await chrome.storage.local.get('debugLog')).debugLog || [])
      .then((entries) => sendResponse({ entries }))
      .catch(() => sendResponse({ entries: [] }));
    return true;
  }

  if (msg.type === 'clearLog') {
    enqueue(() => chrome.storage.local.set({ debugLog: [] }))
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }
});
