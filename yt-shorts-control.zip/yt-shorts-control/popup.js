const { mergeSettings, formatEntry, buildReport, copyText } = YTS;
const $ = (s) => document.querySelector(s);
const PAGE_KEYS = ['home', 'search', 'subs', 'watch'];
const PAGE_LABEL = { home: 'Home', search: 'Search', subs: 'Subscriptions', watch: 'Video page', other: 'Other page' };
const MODE_LABEL = { show: 'Show', hide: 'Hide', column: 'Column' };

let settings = mergeSettings({});
let msgTimer = 0;

function flash(text) {
  $('#msg').textContent = text;
  clearTimeout(msgTimer);
  msgTimer = setTimeout(() => { $('#msg').textContent = ''; }, 3000);
}

async function save(patch) {
  settings = mergeSettings(Object.assign({}, settings, patch));
  render();
  await chrome.storage.sync.set(patch);
}

function render() {
  document.querySelectorAll('#modes button').forEach((b) => {
    const on = b.dataset.mode === settings.mode;
    b.classList.toggle('on', on);
    b.setAttribute('aria-pressed', String(on));
  });
  PAGE_KEYS.forEach((k) => { $('#p-' + k).checked = !!settings.pages[k]; });
  $('#showWidget').checked = settings.showWidget;
  $('#hideGuide').checked = settings.hideGuide;
  $('#verbose').checked = settings.verbose;
  $('#width').value = settings.columnWidth;
  $('#widthVal').textContent = settings.columnWidth + 'px';
}

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function getStatus() {
  const tab = await activeTab();
  if (!tab || !tab.url || !tab.url.startsWith('https://www.youtube.com/')) return { error: 'Open youtube.com to see live status.' };
  try {
    return { tab, info: await chrome.tabs.sendMessage(tab.id, { type: 'status' }) };
  } catch (_) {
    return { tab, error: 'Reload this YouTube tab to activate the extension.' };
  }
}

async function refreshStatus() {
  const s = await getStatus();
  $('#status').textContent = s.error
    ? s.error
    : `${PAGE_LABEL[s.info.page]}: ${MODE_LABEL[s.info.mode]} mode, ${s.info.shorts} Shorts found`;
}

async function getEntries() {
  const { debugLog = [] } = await chrome.storage.local.get('debugLog');
  return debugLog;
}

async function refreshLog() {
  const entries = await getEntries();
  const ta = $('#log');
  const atBottom = ta.scrollTop + ta.clientHeight >= ta.scrollHeight - 8;
  ta.value = entries.slice(-300).map(formatEntry).join('\n');
  if (atBottom) ta.scrollTop = ta.scrollHeight;
  $('#logCount').textContent = `(${entries.length} entries)`;
}

/* ---- events ---- */
document.querySelectorAll('#modes button').forEach((b) => b.addEventListener('click', () => save({ mode: b.dataset.mode })));
PAGE_KEYS.forEach((k) => $('#p-' + k).addEventListener('change', (e) => save({ pages: Object.assign({}, settings.pages, { [k]: e.target.checked }) })));
['showWidget', 'hideGuide', 'verbose'].forEach((k) => $('#' + k).addEventListener('change', (e) => save({ [k]: e.target.checked })));

let widthTimer = 0;
$('#width').addEventListener('input', (e) => {
  $('#widthVal').textContent = e.target.value + 'px';
  clearTimeout(widthTimer);
  widthTimer = setTimeout(() => save({ columnWidth: Number(e.target.value) }), 150);
});

$('#copy').addEventListener('click', async () => {
  const entries = await getEntries();
  const s = await getStatus();
  const ok = await copyText(buildReport({ entries, settings, context: s.info || { note: s.error } }));
  flash(ok ? `Copied ${entries.length} entries` : 'Copy failed - select the text and copy manually');
});

$('#diag').addEventListener('click', async () => {
  const s = await getStatus();
  if (s.error) return flash(s.error);
  try {
    await chrome.tabs.sendMessage(s.tab.id, { type: 'diagnose' });
    flash('Diagnostics added to log');
    setTimeout(refreshLog, 900);
  } catch (_) { flash('Could not reach the tab - reload it'); }
});

$('#clear').addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'clearLog' });
  await refreshLog();
  flash('Log cleared');
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.debugLog) refreshLog();
  if (area === 'sync') {
    const next = Object.assign({}, settings);
    Object.keys(changes).forEach((k) => { next[k] = changes[k].newValue; });
    settings = mergeSettings(next);
    render();
    setTimeout(refreshStatus, 200);
  }
});

/* ---- init ---- */
(async function init() {
  settings = mergeSettings(await chrome.storage.sync.get(null));
  render();
  refreshLog();
  refreshStatus();
  setInterval(refreshStatus, 3000);
})();
