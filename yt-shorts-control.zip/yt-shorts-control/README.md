# Shorts Control for YouTube

Show, hide, or move YouTube Shorts into their own column on the right.

## Install (unpacked)

1. Unzip the folder.
2. Open `chrome://extensions` and turn on **Developer mode**.
3. Click **Load unpacked** and pick the `yt-shorts-control` folder.
4. Reload any open YouTube tabs.

## Features

- **Toggle on the page** (Home, Search, Subscriptions): Show / Hide / Column.
- **Column mode**: Shorts are pulled out of the feed into a scrollable list on the right; regular videos stay in the main area. New Shorts are added as you scroll.
- **Hide mode**: removes Shorts shelves and individual Shorts (including Shorts mixed into search results).
- **Per-page control**: choose which pages the extension applies to, including suggestions on video pages (Column falls back to Hide there).
- **Popup settings**: mode, pages, column width, remove "Shorts" from the left menu, floating toggle on/off.
- **Keyboard shortcut**: Alt+Shift+S cycles modes (change at `chrome://extensions/shortcuts`).
- **Debug log**: open it from the bug button on the page toggle or from the popup. **Copy log** copies a report with version, browser, settings, page state and every log line. **Run diagnostics** records element counts and the DOM path of any Short that isn't being caught.

## If YouTube changes its layout

Run diagnostics, then copy the log. Lines starting with `Short links NOT covered` show the element path to add to `ITEM_SEL` in `content.js` (and to the selector list in `content.css`).

## Files

- `manifest.json` - extension definition (Manifest V3)
- `content.js` / `content.css` - detection, hiding, toggle, Shorts column
- `popup.html` / `popup.js` - settings and log viewer
- `background.js` - log storage, keyboard shortcut
- `shared.js` - defaults and log formatting shared by all parts
