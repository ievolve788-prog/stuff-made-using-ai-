/* Shared by content script, popup and service worker. */
(function (g) {
  'use strict';

  const MODES = ['show', 'hide', 'column'];

  const DEFAULTS = {
    mode: 'column',                 // show | hide | column
    pages: { home: true, search: true, subs: true, watch: true },
    showWidget: true,               // floating toggle on Home / Search / Subscriptions
    collapsed: false,               // floating toggle minimised to a small button
    hideGuide: false,               // also hide the "Shorts" entry in the left menu
    columnWidth: 300,               // px
    verbose: true                   // include debug-level entries in the log
  };

  function mergeSettings(p) {
    p = p || {};
    const s = Object.assign({}, DEFAULTS);
    Object.keys(DEFAULTS).forEach((k) => {
      if (k !== 'pages' && p[k] !== undefined) s[k] = p[k];
    });
    s.pages = Object.assign({}, DEFAULTS.pages, p.pages || {});
    if (!MODES.includes(s.mode)) s.mode = DEFAULTS.mode;
    s.columnWidth = Math.min(480, Math.max(220, Number(s.columnWidth) || DEFAULTS.columnWidth));
    return s;
  }

  const pad = (n, l = 2) => String(n).padStart(l, '0');

  function fmtTime(t) {
    const d = new Date(t);
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ` +
      `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}.${pad(d.getMilliseconds(), 3)}`;
  }

  function formatEntry(e) {
    const src = e.src + (e.tab != null ? '#' + e.tab : '');
    let line = `${fmtTime(e.t)} ${String(e.lvl).toUpperCase().padEnd(5)} [${src}] ${e.msg}`;
    if (e.data !== undefined) {
      try { line += ' ' + JSON.stringify(e.data); } catch (_) { line += ' [unserialisable]'; }
    }
    return line;
  }

  function buildReport({ entries, settings, context }) {
    const m = chrome.runtime.getManifest();
    const head = [
      `=== ${m.name} v${m.version} - debug report ===`,
      `Generated: ${new Date().toISOString()}`,
      `Browser:   ${navigator.userAgent}`,
      `Settings:  ${JSON.stringify(settings)}`,
      context ? `Context:   ${JSON.stringify(context)}` : null,
      `=== Log (${entries.length} entries, oldest first) ===`
    ].filter(Boolean);
    return head.concat(entries.map(formatEntry)).join('\n');
  }

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch (_) { /* fall through to legacy path */ }
    try {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.cssText = 'position:fixed;top:-1000px;opacity:0';
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand('copy');
      ta.remove();
      return ok;
    } catch (_) {
      return false;
    }
  }

  g.YTS = { MODES, DEFAULTS, mergeSettings, fmtTime, formatEntry, buildReport, copyText };
})(globalThis);
